<?php

$page_security = 'SA_SUPPTRANSVIEW';

$path_to_root = "../..";

include($path_to_root . "/purchasing/includes/po_class.inc");

include($path_to_root . "/includes/session.inc");

$js = "";

if ($use_popup_windows)
	$js .= get_js_open_window(900, 500);

page(_($help_context = "View Batch"), true, false, "", $js);

include($path_to_root . "/purchasing/includes/purchasing_ui.inc");

if (!isset($_GET['trans_no']))
{
	die ("<BR>" . _("This page must be called with a Purchase Order Delivery number to review."));
}

$purchase_order = new purch_order;

display_heading(_("Item") . " #" . $_GET['stock_id']);

// For Serial
if($_GET['type_no'] == ST_SERIAL)
{
    $result = get_serial_no_for_view($_GET["trans_no"], $_GET["stock_id"]);
    if(db_num_rows($result) != 0)
    {
        display_heading(_("Serial Numbers"));

        start_table(TABLESTYLE, "colspan=9 width=50%");

        $th = array(_("Item Code"), _("Serial No."));

        table_header($th);

        $result = get_serial_no_for_view($_GET["trans_no"], $_GET["stock_id"]);

        while($myrow = db_fetch($result))
        {
            alt_table_row_color($k);
            label_cell("<b>".$myrow['stock_id']."</b>");
            label_cell("<b>".$myrow['serial_no']."</b>");
        }
    }
}


end_table(1);
// For Batch
if($_GET['type_no'] == ST_BATCH_)
{
    $result = get_batch_no_for_view_($_GET["trans_no"], $_GET["stock_id"]);
    if(db_num_rows($result) != 0)
    {
        display_heading(_("Batch Numbers"));

        start_table(TABLESTYLE, "colspan=9 width=50%");

        $th = array(_("Item Code"), _("Batch No."));

        table_header($th);

        $result = get_batch_no_for_view_($_GET["trans_no"], $_GET["stock_id"]);
        while ($myrow2 = db_fetch($result)) {
            alt_table_row_color($k);
            label_cell("<b>" . $myrow2['stock_id'] . "</b>");
            label_cell("<b>" . $myrow2['batch_no'] . "</b>");
        }
    }
}

end_table(2);


// For Both
if($_GET['type_no'] == ST_BOTHVIEWS)
{
    $result = get_serial_no_for_view($_GET["trans_no"], $_GET["stock_id"]);
    if(db_num_rows($result) != 0)
    {
        display_heading(_("Serial Numbers"));

        start_table(TABLESTYLE, "colspan=9 width=50%");

        $th = array(_("Item Code"), _("Serial No."));

        table_header($th);

        $result = get_serial_no_for_view($_GET["trans_no"], $_GET["stock_id"]);

        while($myrow = db_fetch($result))
        {
            alt_table_row_color($k);
            label_cell("<b>".$myrow['stock_id']."</b>");
            label_cell("<b>".$myrow['serial_no']."</b>");
        }
    }
    end_table(1);

    $result = get_batch_no_for_view_($_GET["trans_no"], $_GET["stock_id"]);
    if(db_num_rows($result) != 0)
    {
        display_heading(_("Batch Numbers"));

        start_table(TABLESTYLE, "colspan=9 width=50%");

        $th = array(_("Item Code"), _("Batch No."));

        table_header($th);

        $result = get_batch_no_for_view_($_GET["trans_no"], $_GET["stock_id"]);
        while ($myrow2 = db_fetch($result)) {
            alt_table_row_color($k);
            label_cell("<b>" . $myrow2['stock_id'] . "</b>");
            label_cell("<b>" . $myrow2['batch_no'] . "</b>");
        }
    }
}

end_table(2);

is_voided_display(ST_SUPPRECEIVE, $_GET['trans_no'], _("This delivery has been voided."));

end_page(true, false, false, ST_SUPPRECEIVE, $_GET['trans_no']);

?>