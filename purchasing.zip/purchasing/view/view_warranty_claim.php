<?php
$page_security = 'SA_SUPPTRANSVIEW';
$path_to_root = "../..";
include($path_to_root . "/purchasing/includes/warranty_claim_class.inc");

include($path_to_root . "/includes/session.inc");
include($path_to_root . "/purchasing/includes/purchasing_ui.inc");

$js = "";
if ($use_popup_windows)
	$js .= get_js_open_window(900, 500);
page(_($help_context = "View Warranty Claim"), true, false, "", $js);


if (!isset($_GET['trans_no']))
{
	die ("<br>" . _("This page must be called with a purchase order number to review."));
}

display_heading(_("Warranty Claim") . " #" . $_GET['trans_no']);

$purchase_order = new warranty_claim();

read_po_warranty_claim($_GET['trans_no'], $purchase_order);
echo "<br>";
display_po_summary_req_warranty_claim($purchase_order, true);

start_table(TABLESTYLE, "width=90%", 6);
echo "<tr><td valign=top>"; // outer table

display_heading2(_("Line Details"));

start_table(TABLESTYLE, "colspan=9 width=100%");

$th = array(_("Item Code"), _("Item Title"),_("Item Description"), _("Quantity"), _("Unit"),/*("Equipment.model"),("Equipment.serial"),*/("Cost Center"),/*("Category"),*/ _("Price"),
	_("Requested By"), _("Line Total"), _("Quantity Received"), _("Quantity Invoiced"));
table_header($th);
$total = $k = 0;
$overdue_items = false;

foreach ($purchase_order->line_items as $stock_item)
{

	$line_total = $stock_item->quantity * $stock_item->price;

	// if overdue and outstanding quantities, then highlight as so
	if (($stock_item->quantity - $stock_item->qty_received > 0)	&&
		date1_greater_date2(Today(), $stock_item->req_del_date))
	{
		start_row("class='overduebg'");
		$overdue_items = true;
	}
	else
	{
		alt_table_row_color($k);
	}

	label_cell($stock_item->stock_id);
	label_cell($stock_item->item_description);
	label_cell($stock_item->long_desc);
	$dec = get_qty_dec($stock_item->stock_id);
	qty_cell($stock_item->quantity, false, $dec);
	label_cell($stock_item->units);

	label_cell(get_dimension_for_purchase_order_req($stock_item->cost_center));

	label_cell($stock_item->price);
	label_cell($stock_item->req_del_date);
	amount_cell($line_total);
	qty_cell($stock_item->qty_received, false, $dec);
	qty_cell($stock_item->qty_inv, false, $dec);
	end_row();

	$total += $line_total;
}

$display_sub_tot = number_format2($total,user_price_dec());
label_row(_("Sub Total"), $display_sub_tot,
	"align=right colspan=8", "nowrap align=right",2);

$taxes = $purchase_order->get_taxes();
$tax_total = display_edit_tax_items($taxes, 6, $purchase_order->tax_included,2);

$display_total = price_format(($total + $tax_total));

start_row();
label_cells(_("Amount Total"), $display_total, "colspan=8 align='right'","align='right'");
label_cell('', "colspan=2");
end_row();

end_table();

if ($overdue_items)
	display_note(_("Marked items are overdue."), 0, 0, "class='overduefg'");

//----------------------------------------------------------------------------------------------------

$k = 0;

$grns_result = get_po_for_short_material($_GET['trans_no'], ST_WARRANTYCLAIM);

if (db_num_rows($grns_result) > 0)
{
    echo "</td><td valign=top>"; // outer table

    display_heading2(_("Purchase Orders"));
    start_table(TABLESTYLE);
    $th = array(_("#"), _("Reference"), _("Delivered On"));
    table_header($th);
    while ($myrow = db_fetch($grns_result))
    {
        alt_table_row_color($k);

        label_cell(get_trans_view_str(ST_PURCHORDER, $myrow["order_no"]));
        label_cell($myrow["reference"]);
        label_cell(sql2date($myrow["delivery_date"]));
        $Order_No = $myrow["order_no"];
        end_row();
    }
    end_table();
}
$k = 0;
// jaaky GRN ka header pakarh .. !!!
$grns_result = get_header_of_grn($Order_No);
$k = 0 ;
if (db_num_rows($grns_result) > 0)
{
    echo "</td><td valign=top>"; // outer table
    display_heading2(_("GRN"));
    start_table(TABLESTYLE);
    $th = array(_("#"), _("Reference"), _("Date"));
    table_header($th);
    while ($myrow = db_fetch($grns_result))
    {
        alt_table_row_color($k);
        label_cell(get_trans_view_str(ST_SUPPRECEIVE, $myrow["grn_no"]));
        label_cell($myrow["reference"]);
        label_cell(sql2date($myrow["delivery_date"]));
        end_row();
    }
    end_table();
}

$grns_result = get_invoice_header($Order_No);
$k = 0;

if (db_num_rows($grns_result) > 0)
{
    echo "</td><td valign=top>"; // outer table
    display_heading2(_("Invoice"));
    start_table(TABLESTYLE);
    $th = array(_("#"), _("Reference"), _("Date"));
    table_header($th);
    while ($myrow = db_fetch($grns_result))
    {
        alt_table_row_color($k);
        label_cell(get_trans_view_str(ST_SUPPINVOICE, $myrow["trans_no"]));
        label_cell($myrow["supp_reference"]);
        label_cell(sql2date($myrow["tran_date"]));
        end_row();
    }
    end_table();
}

echo "</td></tr>";

end_table(1); // outer table

//----------------------------------------------------------------------------------------------------

end_page(true, false, false, ST_PURCHORDER, $_GET['trans_no']);

?>