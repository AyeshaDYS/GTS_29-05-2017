<?php
$path_to_root = "..";
$page_security = 'SA_PURCHASEORDER';

include_once($path_to_root . "/purchasing/includes/batch_class.inc");

include_once($path_to_root . "/includes/session.inc");

include_once($path_to_root . "/purchasing/includes/purchasing_ui.inc");

include_once($path_to_root . "/purchasing/includes/db/suppliers_db.inc");

include_once($path_to_root . "/reporting/includes/reporting.inc");


set_page_security( @$_SESSION['batch']->trans_type,
	array(	ST_PURCHORDER => 'SA_PURCHASEORDER',
			ST_SUPPRECEIVE => 'SA_GRN',
			ST_SUPPINVOICE => 'SA_SUPPLIERINVOICE'),
	array(	'NewOrder' => 'SA_PURCHASEORDER',
			'ModifyOrderNumber' => 'SA_PURCHASEORDER',
			'AddedID' => 'SA_PURCHASEORDER',
			'NewGRN' => 'SA_GRN',
			'AddedGRN' => 'SA_GRN',
			'NewInvoice' => 'SA_SUPPLIERINVOICE',
			'AddedPI' => 'SA_SUPPLIERINVOICE')
);

$js = '';
if ($use_popup_windows)
	$js .= get_js_open_window(900, 500);
if ($use_date_picker)
	$js .= get_js_date_picker();


if (isset($_GET['ModifyOrderNumber']) && is_numeric($_GET['ModifyOrderNumber']))
{

	$_SESSION['page_title'] = _($help_context = "Modify Purchase Order- #") . $_GET['ModifyOrderNumber'];

	create_new_po_batch(ST_PURCHORDER, $_GET['ModifyOrderNumber']);

	copy_from_cart_batch();

}
elseif (isset($_GET['AddBatch']))
{

	$_SESSION['page_title'] = _($help_context = "Batch Entry");
	create_new_po_batch(ST_PURCHORDER, 0);
    $_SESSION['batch']->quantity = $_GET['qty'];
    $_SESSION['batch']->stock_id = $_GET['stock_id'];
    $_SESSION['batch']->Type2 = ST_SUPPRECEIVE;
    $_SESSION['batch']->parent_id= $_GET['parent_id'];
    $_SESSION['batch']->loc_code = $_GET['loc_code'];
    copy_from_cart_batch();
}

page($_SESSION['page_title'], false, false, "", $js);
//---------------------------------------------------------------------------------------------------

check_db_has_suppliers(_("There are no suppliers defined in the system."));

check_db_has_purchasable_items(_("There are no purchasable inventory items defined in the system."));

//---------------------------------------------------------------------------------------------------------------

if (isset($_GET['AddedBatch']))
{
	$order_no = $_GET['AddedID'];
		display_notification_centered(_("Batch# has been entered"));

//	display_note(get_supplier_trans_view_str($trans_type, $order_no, _("&View this order"),false,'','', $Type3), 0, 1,$_GET['BatchOrder']);
//
//	display_note(print_document_link($order_no, _("&Print This Order"), true, $trans_type), 0, 1);
//
//	display_note(print_document_link($order_no, _("&Email This Order"), true, $trans_type, false, "printlink", "", 1));
//	echo "<br>";
//	hyperlink_params($path_to_root . "/purchasing/po_receive_items_consignment.php", _("&Receive Items on this Order"), "PONumber=$order_no&Type3=$Type3");
//	echo "<br>";
//	hyperlink_params($path_to_root . "/purchasing/po_entry_items1.php", _("&Place Consignment against this Order"), "AddOrder=$order_no"."&Type2=".ST_PURCHORDER);
//	echo "<br>";
//	hyperlink_params($_SERVER['PHP_SELF'], _("Enter &Another Purchase Order"), "NewOrder=yes");
//
//	hyperlink_no_params($path_to_root."/purchasing/inquiry/po_search.php", _("Select An &Outstanding Consignment Status"));
//
	display_footer_exit();	

} elseif (isset($_GET['AddedGRN'])) {

	$trans_no = $_GET['AddedGRN'];
	$trans_type = ST_SUPPRECEIVE;

	display_notification_centered(_("Direct GRN has been entered"));

	display_note(get_trans_view_str($trans_type, $trans_no, _("&View this GRN")), 0);

    $clearing_act = get_company_pref('grn_clearing_act');

	if ($clearing_act)	
		display_note(get_gl_view_str($trans_type, $trans_no, _("View the GL Journal Entries for this Delivery")), 1);
// not yet
//	display_note(print_document_link($trans_no, _("&Print This GRN"), true, $trans_type), 0, 1);

	_("Entry purchase &invoice for this receival", "New=1");

	hyperlink_params("$path_to_root/admin/attachments.php", _("Add an Attachment"), 
		"filterType=$trans_type&trans_no=$trans_no");

	hyperlink_params($_SERVER['PHP_SELF'], _("Enter &Another GRN"), "NewGRN=Yes");
	
	display_footer_exit();	

} elseif (isset($_GET['AddedPI'])) {

	$trans_no = $_GET['AddedPI'];
	$trans_type = ST_SUPPINVOICE;

	display_notification_centered(_("Direct Purchase Invoice has been entered"));

	display_note(get_supplier_trans_view_str_consignment($trans_type, $trans_no, _("&View this Invoice")), 0);

// not yet
//	display_note(print_document_link($trans_no, _("&Print This Invoice"), true, $trans_type), 0, 1);

	display_note(get_gl_view_str($trans_type, $trans_no, _("View the GL Journal Entries for this Invoice")), 1);

	hyperlink_params("$path_to_root/purchasing/supplier_payment.php", _("Entry supplier &payment for this invoice"),
		"PInvoice=".$trans_no);

	hyperlink_params("$path_to_root/admin/attachments.php", _("Add an Attachment"), 
		"filterType=$trans_type&trans_no=$trans_no");

	hyperlink_params($_SERVER['PHP_SELF'], _("Enter &Another Direct Invoice"), "NewInvoice=Yes");
	
	display_footer_exit();	
}
elseif(isset($_GET['AddedBatch']))
{
    display_notification_centered(_("Batch# has been entered."));
    display_footer_exit();
}
//--------------------------------------------------------------------------------------------------
function line_start_focus_batch()
{
  global $Ajax;

  $Ajax->activate('items_table');
  set_focus('_stock_id_edit');
}
//--------------------------------------------------------------------------------------------------
function unset_form_variables_batch() {
	unset($_POST['stock_id']);
    unset($_POST['qty']);
    unset($_POST['price']);
    unset($_POST['req_del_date']);
}

//---------------------------------------------------------------------------------------------------

function handle_delete_item_batch($line_no)
{
	if($_SESSION['batch']->some_already_received($line_no) == 0)
	{
		$_SESSION['batch']->remove_from_order($line_no);
		unset_form_variables_batch();
	} 
	else 
	{
		display_error(_("This item cannot be deleted because some of it has already been received."));
	}	
    line_start_focus_batch();
}

//---------------------------------------------------------------------------------------------------

function handle_cancel_po_batch()
{
	global $path_to_root;
	
	//need to check that not already dispatched or invoiced by the supplier
	if(($_SESSION['batch']->order_no != 0) && $_SESSION['batch']->any_already_received() == 1)
	{
		display_error(_("This order cannot be cancelled because some of it has already been received.") 
			. "<br>" . _("The line item quantities may be modified to quantities more than already received. prices cannot be altered for lines that have already been received and quantities cannot be reduced below the quantity already received."));
		return;
	}
	
	if($_SESSION['batch']->order_no != 0)
	{
		delete_po_batch($_SESSION['batch']->order_no);
	}
	else
	{
		unset($_SESSION['batch']);
		meta_forward($path_to_root.'/index.php','application=AP');
	}

	$_SESSION['batch']->clear_items();
	$_SESSION['batch'] = new batch_order;

	display_notification(_("This purchase order has been cancelled."));

	hyperlink_params($path_to_root . "/purchasing/po_entry_items.php", _("Enter a new purchase order"), "NewOrder=Yes");
	echo "<br>";

	end_page();
	exit;
}

//---------------------------------------------------------------------------------------------------
function handle_update_item_batch()
{
    $_SESSION['batch']->update_order_item($_POST['line_no'], $_POST['batch_no']);
    unset_form_variables_batch();
    line_start_focus_batch();
}

//---------------------------------------------------------------------------------------------------

function handle_add_new_item_batch()
{
    $Qty = round($_SESSION['batch']->quantity);
    $Stock_ID = $_SESSION['batch']->stock_id;

    for($i = 1; $i <= $Qty; $i++)
    {
        $_SESSION['batch']->add_to_order(count($_SESSION['batch']->line_items), '', $Qty, $Stock_ID);
    }
    unset_form_variables_batch();
    line_start_focus_batch();
}

//---------------------------------------------------------------------------------------------------

function can_commit_batch()
{
    foreach ($_SESSION['batch']->line_items as $line_no => $po_line)
    {
        $result = get_exist_batch($po_line->batch_no, $_SESSION['batch']->stock_id);
        if(db_num_rows($result) != 0)
        {
            display_error("This batch# has already been added against this item code. batch# ".$_POST['batch_no'.$line_no]);
            set_focus('batch_no'.$line_no);
            return false;
        }
    }
    return true;
}

function handle_commit_order_batch()
{
    foreach ($_SESSION['batch']->line_items as $line_no => $po_line)
    {
        $_SESSION['batch']->line_items[$line_no]->batch_no = $_POST['batch_no'.$line_no];
    }
    if (can_commit_batch())
    {
        $cart = &$_SESSION['batch'];
        copy_to_cart_batch();
		if ($cart->order_no == 0)
		{
			$order_no = add_po_temporary_batch($cart);
			$cart->order_no = $order_no;
			if ($cart->trans_type == ST_PURCHORDER)
			{
				meta_forward($_SERVER['PHP_SELF'], "AddedBatch=$order_no");
			}
		}
	}
}
//---------------------------------------------------------------------------------------------------
$id = find_submit('Delete');
if ($id != -1)
	handle_delete_item_batch($id);

if (isset($_POST['Commit']))
	handle_commit_order_batch();

if (isset($_POST['UpdateLine']))
	handle_update_item_batch();

if (isset($_POST['EnterLine']) && $_SESSION['batch']->Type3 == 0){
    $_SESSION['batch']->Type3 = 1;
    handle_add_new_item_batch();
}

if (isset($_POST['CancelOrder'])) 
	handle_cancel_po_batch();

if (isset($_POST['CancelUpdate']))
	unset_form_variables_batch();

if (isset($_POST['CancelUpdate']) || isset($_POST['UpdateLine']))
	line_start_focus_batch();
//---------------------------------------------------------------------------------------------------
start_form();

echo "<br>";

display_po_items_batch($_SESSION['batch']);

//start_table(TABLESTYLE2);
//textarea_row(_("Memo:"), 'Comments', null, 70, 4);
//
//end_table(1);

div_start('controls', 'items_table');
$process_txt = _("Save Batch");
$update_txt = _("Update Order");
$cancel_txt = _("Cancel Order");
if ($_SESSION['batch']->trans_type == ST_SUPPRECEIVE)
{
	$process_txt = _("Process GRN");
	$update_txt = _("Update GRN");
	$cancel_txt = _("Cancel GRN");
}	
elseif ($_SESSION['batch']->trans_type == ST_SUPPINVOICE)
{
	$process_txt = _("Process Invoice");
	$update_txt = _("Update Invoice");
	$cancel_txt = _("Cancel Invoice");
}
if ($_SESSION['batch']->order_has_items())
{

	if ($_SESSION['batch']->order_no == 0)
		submit_center_first('Commit', $process_txt, '', 'default');
	else
		submit_center_first('Commit', $update_txt, '', 'default');
//	submit_center_last('CancelOrder', $cancel_txt);
}
//else
//	submit_center('CancelOrder', $cancel_txt, true, false, 'cancel');


div_end();

//---------------------------------------------------------------------------------------------------

end_form();

end_page();
?>