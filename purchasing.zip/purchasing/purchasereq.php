<?php
$path_to_root = "..";
$page_security = 'SA_PURCHASEORDER';
include_once($path_to_root . "/purchasing/includes/po_class_req.inc");
include_once($path_to_root . "/includes/session.inc");
include_once($path_to_root . "/purchasing/includes/purchasing_ui.inc");
include_once($path_to_root . "/purchasing/includes/db/suppliers_db.inc");
include_once($path_to_root . "/reporting/includes/reporting.inc");

set_page_security( @$_SESSION['PO_req']->trans_type,
	array(	ST_PURCHORDER => 'SA_PURCHASEORDER',
		ST_SUPPRECEIVE => 'SA_GRN',
		ST_SUPPINVOICE => 'SA_SUPPLIERINVOICE'),
	array(	'NewOrder' => 'SA_PURCHASEORDER',
		'ModifyOrderNumber' => 'SA_PURCHASEORDER',
		'AddedID' => 'SA_PURCHASEORDER',
		'NewGRN' => 'SA_GRN',
		'AddedGRN' => 'SA_GRN',
		'NewInvoice' => 'SA_SUPPLIERINVOICE',
		'AddedPI' => 'SA_SUPPLIERINVOICE')
);

$js = '';
if ($use_popup_windows)
	$js .= get_js_open_window(900, 500);
if ($use_date_picker)
	$js .= get_js_date_picker();




if (isset($_GET['ModifyOrderNumber']) && is_numeric($_GET['ModifyOrderNumber'])) {

	$_SESSION['page_title'] = _($help_context = "Modify Purchase Requisition #") . $_GET['ModifyOrderNumber'];

	create_new_po_req(ST_PURCHORDER, $_GET['ModifyOrderNumber']);

	copy_from_cart_req();

} elseif (isset($_GET['NewOrder'])) {

	$_SESSION['page_title'] = _($help_context = "Purchase Requisition Entry");
	create_new_po_req(ST_PURCHORDER, 0);
	copy_from_cart_req();
} elseif (isset($_GET['NewGRN'])) {

	$_SESSION['page_title'] = _($help_context = "Direct GRN Entry");
	create_new_po_req(ST_SUPPRECEIVE, 0);
	copy_from_cart_req();
} elseif (isset($_GET['NewInvoice'])) {

	$_SESSION['page_title'] = _($help_context = "Direct Purchase Invoice Entry");
	create_new_po_req(ST_SUPPINVOICE, 0);
	copy_from_cart_req();

}
elseif (isset($_GET['repairing']) && is_numeric($_GET['repairing'])) {


$_SESSION['page_title'] = _($help_context = "Enter Purchase requisition #") ;
	create_new_po_req(ST_PURCHORDER, $_GET['repairing'], $_GET['Type_rep']);
	copy_from_cart_req();


}
page($_SESSION['page_title'], false, false, "", $js);

//---------------------------------------------------------------------------------------------------

check_db_has_suppliers(_("There are no suppliers defined in the system."));

check_db_has_purchasable_items(_("There are no purchasable inventory items defined in the system."));

//---------------------------------------------------------------------------------------------------------------

if (isset($_GET['AddedID']))
{
	$order_no = $_GET['AddedID'];
	$trans_type = ST_PURCHORDER;

	if (!isset($_GET['Updated'])) {
		display_notification_centered(_("Purchase Requisition has been entered"));
		//	hyperlink_params($path_to_root . "/purchasing/po_entry_items.php", _("&Place Order against this Requisition"), "AddRequisition=$order_no" . "&Type_req=" . ST_PURCHASEREQUISITION);
	}
	else
		display_notification_centered(_("Purchase Requisition has been updated") . " #$order_no");

	display_note(get_trans_view_str(ST_PURCHASEREQUISITION, $order_no, _("&View this Requisition")), 0, 1);

	display_note(print_document_link($order_no, _("&Print This Requisition"), true, ST_PURCHASEREQUISITION	), 0, 1);

	display_note(print_document_link($order_no, _("&Email This Requisition"), true, $trans_type, false, "printlink", "", 1));
	echo "<br>";
	$result= check_pr_exist($order_no);

	if($result>0)
	{
		echo "";
		?>

		<script>
			function AlertIt() {

				var answer = confirm (	"PO already Created Against this PR")
				if (answer)
					"alert";
			}
		</script>
		<center><a href="javascript:AlertIt();">Place Order against this Requisition</a></center><?php


	}
	else{
		echo "";
		hyperlink_params($path_to_root . "/purchasing/po_entry_items.php", _("&Place Order against this Requisition"), "AddRequisition=$order_no" . "&Type_req=" . ST_PURCHASEREQUISITION);
	}
	//echo $myrow['pr_no'];



echo "<br>";

	hyperlink_params($_SERVER['PHP_SELF'], _("Enter &Another Purchase Requisition"), "NewOrder=yes");

	hyperlink_no_params($path_to_root."/purchasing/inquiry/pr_search_completed.php", _("Select An &Outstanding Purchase Requisition"));

	display_footer_exit();

} elseif (isset($_GET['AddedGRN'])) {

	$trans_no = $_GET['AddedGRN'];
	$trans_type = ST_SUPPRECEIVE;

	display_notification_centered(_("Direct GRN has been entered"));

	display_note(get_trans_view_str_requisition($trans_type, $trans_no, _("&View this GRN")), 0);

	$clearing_act = get_company_pref('grn_clearing_act');
	if ($clearing_act)
		display_note(get_gl_view_str($trans_type, $trans_no, _("View the GL Journal Entries for this Delivery")), 1);
// not yet
//	display_note(print_document_link($trans_no, _("&Print This GRN"), true, $trans_type), 0, 1);

	hyperlink_params("$path_to_root/purchasing/supplier_invoice.php",
		_("Entry purchase &invoice for this receival"), "New=1");

	hyperlink_params("$path_to_root/admin/attachments.php", _("Add an Attachment"),
		"filterType=$trans_type&trans_no=$trans_no");

	hyperlink_params($_SERVER['PHP_SELF'], _("Enter &Another GRN"), "NewGRN=Yes");

	display_footer_exit();

} elseif (isset($_GET['AddedPI'])) {

	$trans_no = $_GET['AddedPI'];
	$trans_type = ST_SUPPINVOICE;

	display_notification_centered(_("Direct Purchase Invoice has been entered"));

	display_note(get_trans_view_str($trans_type, $trans_no, _("&View this Invoice")), 0);

// not yet
//	display_note(print_document_link($trans_no, _("&Print This Invoice"), true, $trans_type), 0, 1);

	display_note(get_gl_view_str($trans_type, $trans_no, _("View the GL Journal Entries for this Invoice")), 1);

	hyperlink_params("$path_to_root/purchasing/supplier_payment.php", _("Entry supplier &payment for this invoice"),
		"PInvoice=".$trans_no);

	hyperlink_params("$path_to_root/admin/attachments.php", _("Add an Attachment"),
		"filterType=$trans_type&trans_no=$trans_no");

	hyperlink_params($_SERVER['PHP_SELF'], _("Enter &Another Direct Invoice"), "NewInvoice=Yes");

	display_footer_exit();
}





if($_SESSION['PO_req']->trans_no == 0)
{
	$pid = get_next_reference(ST_PURCHASEID);

	$_POST['purchase_id'] = $pid ;

	//$Ajax->activate('reference_new');
}


if (list_updated('select_pr') || $_POST['select_pr'] != '')
{
	// when branch is selected via external editor also customer can change
	$gst_number1 = get_gst_req(get_post('select_pr'));
	$_POST['gst_no1'] = $gst_number1;

//	if(get_post('select_gst') == ST_GST)
//		$_SESSION['Items']->gst_no1 = 1;
//	else/*(get_post('select_gst') == ST_NON_GST)*/
//		$_SESSION['Items']->gst_no1 = 2;
//
	$Ajax->activate('gst_no1');
//	$Ajax->activate('gst_no1');
}
function get_gst_req($type){
	global $Refs;

	if($type == 0)
		return '';

	return $Refs->get_next($type);

}
//--------------------------------------------------------------------------------------------------

function line_start_focus_repairing() {
	global $Ajax;

	$Ajax->activate('items_table');
	set_focus('_stock_id_edit');
}
//--------------------------------------------------------------------------------------------------

function unset_form_variables_repairing() {
	unset($_POST['stock_id']);
	unset($_POST['qty']);
	unset($_POST['price']);
	unset($_POST['req_del_date']);
}

//---------------------------------------------------------------------------------------------------

function handle_delete_item_repairing($line_no)
{
	if($_SESSION['PO_req']->some_already_received($line_no) == 0)
	{
		$_SESSION['PO_req']->remove_from_order($line_no);
		unset_form_variables_repairing();
	}
	else
	{
		display_error(_("This item cannot be deleted because some of it has already been received."));
	}
	line_start_focus_repairing();
}

//---------------------------------------------------------------------------------------------------

function handle_cancel_po_repairing()
{
	global $path_to_root;

	//need to check that not already dispatched or invoiced by the supplier
	if(($_SESSION['PO_req']->order_no != 0) &&
		$_SESSION['PO_req']->any_already_received() == 1)
	{
		display_error(_("This order cannot be cancelled because some of it has already been received.")
			. "<br>" . _("The line item quantities may be modified to quantities more than already received. prices cannot be altered for lines that have already been received and quantities cannot be reduced below the quantity already received."));
		return;
	}

	if($_SESSION['PO_req']->order_no != 0)
	{
		delete_po_req($_SESSION['PO_req']->order_no);
	} else {
		unset($_SESSION['PO_req']);
		meta_forward($path_to_root.'/index.php','application=AP');
	}

	$_SESSION['PO_req']->clear_items();
	$_SESSION['PO_req'] = new purch_order_req;

	display_notification(_("This Claim For Short Material has been cancelled."));

	hyperlink_params($path_to_root . "/purchasing/po_entry_items.php", _("Enter a new purchase Requisition"), "NewOrder=Yes");
	echo "<br>";

	end_page();
	exit;
}

//---------------------------------------------------------------------------------------------------

function check_data_repairing()
{

	if(!get_post('stock_id_text', true)) {
		display_error( _("Item description cannot be empty."));
		set_focus('stock_id_edit');
		return false;
	}

	$dec = get_qty_dec($_POST['stock_id']);
	$min = 1 / pow(10, $dec);
	if (!check_num('qty',$min))
	{
		$min = number_format2($min, $dec);
		display_error(_("The quantity of the order item must be numeric and not less than ").$min);
		set_focus('qty');
		return false;
	}

	if (!check_num('price', 0))
	{
		display_error(_("The price entered must be numeric and not less than zero."));
		set_focus('price');
		return false;
	}

	if ($_SESSION['PO_req']->trans_type == ST_PURCHORDER && !is_date($_POST['req_del_date'])){
		display_error(_("The date entered is in an invalid format."));
		set_focus('req_del_date');
		return false;
	}


	return true;
}

//---------------------------------------------------------------------------------------------------

function handle_update_item_repairing()
{
	$allow_update = check_data_repairing();

	if ($allow_update)
	{
		if ($_SESSION['PO_req']->line_items[$_POST['line_no']]->qty_inv > input_num('qty') ||
			$_SESSION['PO_req']->line_items[$_POST['line_no']]->qty_received > input_num('qty'))
		{
			display_error(_("You are attempting to make the quantity ordered a quantity less than has already been invoiced or received.  This is prohibited.") .
				"<br>" . _("The quantity received can only be modified by entering a negative receipt and the quantity invoiced can only be reduced by entering a credit note against this item."));
			set_focus('qty');
			return;
		}

		$_SESSION['PO_req']->update_order_item($_POST['line_no'], input_num('qty'), input_num('price'),
			@$_POST['req_del_date'], $_POST['item_description'], get_post('cost_center'), get_post('category_id'), get_post('item_title'),$_POST['long_desc']);
		unset_form_variables_repairing();
	}
	line_start_focus_repairing();
}

//---------------------------------------------------------------------------------------------------

function handle_add_new_item_repairing()
{

	$allow_update = check_data_repairing();

	if ($allow_update == true)
	{
		if (count($_SESSION['PO_req']->line_items) > 0)
		{

			foreach ($_SESSION['PO_req']->line_items as $order_item)
			{
				if (($order_item->stock_id == $_POST['stock_id']))
				{
					display_warning(_("The selected item is already on this order."));
				}
			}
		}

		if ($allow_update == true)
		{

//			display_error("ghghg");
//			$result = display_po_header_req($_POST['stock_id']);
//
//			if (db_num_rows($result) == 0)
//			{
//				$allow_update = false;
//			}
//
//			if ($allow_update)
//			{


			$myrow = db_fetch($result);

			$_SESSION['PO_req']->add_to_order(count($_SESSION['PO_req']->line_items), $_POST['stock_id'], input_num('qty'),
				get_post('stock_id_text'), //$myrow["description"],
				input_num('price'), '', // $myrow["units"], (retrived in cart)
				$_SESSION['PO_req']->trans_type == ST_PURCHORDER ? $_POST['req_del_date'] : '', 0, 0,
				get_post('cost_center'), get_post('category_id'), $_POST['item_title'],$_POST['long_desc']);

			unset_form_variables_repairing();
			$_POST['stock_id']	= "";
//	   		}
//	   		else
//	   		{
//			     display_error(_("The selected item does not exist or it is a kit part and therefore cannot be purchased."));
//		   	}

		} /* end of if not already on the order and allow input was true*/
	}
	line_start_focus_repairing();
}

//---------------------------------------------------------------------------------------------------

function can_commit_repairing()
{
	global $Refs;

	if (!get_post('supplier_id'))
	{
		display_error(_("There is no supplier selected."));
		set_focus('supplier_id');
		return false;
	}

	if ($_POST['voucher_date'] !=  date('d-m-Y'))
	{
		display_error(_("Voucher date should not accept past or future date."));
		set_focus('voucher_date');
		return false;
	}
	if ($_POST['pr_date'] !=  date('d-m-Y'))
	{
		display_error(_("PR date should not accept past or future date."));
		set_focus('pr_date');
		return false;
	}

	if (!is_date($_POST['pr_date']))
	{
		display_error(_("The entered order date is invalid."));
		set_focus('OrderDate');
		return false;
	}

	if ($_SESSION['PO_req']->trans_type != ST_PURCHORDER && !is_date_in_fiscalyear($_POST['OrderDate']))
	{
		display_error(_("The entered date is not in fiscal year"));
		set_focus('OrderDate');
		return false;
	}

	if (($_SESSION['PO_req']->trans_type==ST_SUPPINVOICE) && !is_date($_POST['due_date']))
	{
		display_error(_("The entered due date is invalid."));
		set_focus('due_date');
		return false;
	}

	if (!$_SESSION['PO_req']->order_no)
	{
		if (!$Refs->is_valid(get_post('pr_voucher_no')))
		{
			display_error(_("There is no reference entered for this purchase Requisition."));
			set_focus('pr_voucher_no');
			return false;
		}
		if (!is_new_reference(get_post('pr_voucher_no'), $_SESSION['PO_req']->trans_type))
		{
			display_error(_("The entered reference is already in use."));
			set_focus('pr_voucher_no');
			return false;
		}
	}

	if ($_SESSION['PO_req']->trans_type == ST_SUPPINVOICE && !$Refs->is_valid(get_post('supp_ref')))
	{
		display_error(_("You must enter a supplier's invoice reference."));
		set_focus('supp_ref');
		return false;
	}
	if ($_SESSION['PO_req']->trans_type==ST_SUPPINVOICE
		&& is_reference_already_there($_SESSION['PO_req']->supplier_id, get_post('supp_ref'), $_SESSION['PO_req']->order_no))
	{
		display_error(_("This invoice number has already been entered. It cannot be entered again.") . " (" . get_post('supp_ref') . ")");
		set_focus('supp_ref');
		return false;
	}
//	if ($_SESSION['PO_req']->trans_type == ST_PURCHORDER && get_post('delivery_address') == '')
//	{
//		display_error(_("There is no delivery address specified."));
//		set_focus('delivery_address');
//		return false;
//	}
//	if (get_post('StkLocation') == '')
//	{
//		display_error(_("There is no location specified to move any items into."));
//		set_focus('StkLocation');
//		return false;
//	}
	//if (!db_has_currency_rates($_SESSION['PO_req']->curr_code, $_POST['OrderDate']))
	//	return false;
	if ($_SESSION['PO_req']->order_has_items() == false)
	{
		display_error (_("The order cannot be placed because there are no lines entered on this order."));
		return false;
	}
	if (!get_post('select_pr')){
		display_error(_("PR Type is not selected."));
		set_focus('select_pr');
		return false;
	}
	return true;
}

//---------------------------------------------------------------------------------------------------
//PR Voucher No


if($_SESSION['PO_req']->trans_no == 0)
{
	$pid = get_next_reference(ST_PURCHASEREQUISITION);

	$_POST['pr_voucher_no'] = $pid ;

}

function handle_commit_order_repairing()
{
	$cart = &$_SESSION['PO_req'];

	if (can_commit_repairing()) {

		copy_to_cart_req();
		if ($cart->trans_type != ST_PURCHORDER) {
			// for direct grn/invoice set same dates for lines as for whole document
			foreach ($cart->line_items as $line_no =>$line)
				$cart->line_items[$line_no]->req_del_date = $cart->orig_order_date;
		}
		if ($cart->order_no == 0 || $cart->type ==ST_REPAIRINGSUPPLIER) { // new po/grn/invoice
			/*its a new order to be inserted */
			$ref = $cart->reference;
			if ($cart->trans_type != ST_PURCHORDER) {
				$cart->reference = 'auto';
				begin_transaction();	// all db changes as single transaction for direct document
			}
			$order_no = add_po_req($cart);
			new_doc_date($cart->orig_order_date);
			$cart->order_no = $order_no;

			if ($cart->trans_type == ST_PURCHORDER) {
				unset($_SESSION['PO_req']);
				meta_forward($_SERVER['PHP_SELF'], "AddedID=$order_no");
			}
			//Direct GRN
			if ($cart->trans_type == ST_SUPPRECEIVE)
				$cart->reference = $ref;
			$cart->Comments = $cart->reference; //grn does not hold supp_ref
			foreach($cart->line_items as $key => $line)
				$cart->line_items[$key]->receive_qty = $line->quantity;
			$grn_no = add_grn($cart);
			if ($cart->trans_type == ST_SUPPRECEIVE) {
				commit_transaction(); // save PO+GRN
				unset($_SESSION['PO_req']);
				meta_forward($_SERVER['PHP_SELF'], "AddedGRN=$grn_no");
			}
//			Direct Purchase Invoice
			$inv = new supp_trans(ST_SUPPINVOICE);
			$inv->Comments = $cart->Comments;
			$inv->supplier_id = $cart->supplier_id;
			$inv->transaction_series = $cart->transaction_series;
			$inv->transaction_type = $cart->transaction_type;
			$inv->voucher_date = $cart->voucher_date;
			$inv->pr_type = $cart->pr_type;
			$inv->import_num = $cart->import_num;
			$inv->pr_date = $cart->pr_date;
			$inv->delivery_terms = $cart->delivery_terms;
			$inv->requiredfor = $cart->requiredfor;
			$inv->shipment = $cart->shipment;
			$inv->supp_ref = $cart->supp_ref;
			$inv->material = $cart->material;
			$inv->tran_date = $cart->orig_order_date;
			$inv->due_date = $cart->due_date;
			$inv->reference = $ref;
			$inv->pr_no = $cart->pr_no;
			$inv->supp_reference = $cart->supp_ref;
			$inv->gst_no1 = $cart->gst_no1;
			$inv->purchase_id = $cart->purchase_id;
			$inv->pr_voucher_no = $cart->pr_voucher_no;
			$inv->tax_included = $cart->tax_included;
			$supp = get_supplier($cart->supplier_id);
			$inv->tax_group_id = $supp['tax_group_id'];
			$inv->ov_amount = $inv->ov_gst = $inv->ov_discount = 0;

			foreach($cart->line_items as $key => $line) {
				$inv->add_grn_to_trans($line->grn_item_id, $line->po_detail_rec, $line->stock_id,
					$line->item_description, $line->receive_qty, 0, $line->receive_qty,
					$line->price, $line->price, true, get_standard_cost($line->stock_id), '');
				$inv->ov_amount += round2(($line->receive_qty * $line->price), user_price_dec());
			}
			$taxes = $inv->get_taxes($inv->tax_group_id, 0, false);
			foreach( $taxes as $taxitem) {
				$inv->ov_gst += round2($taxitem['Value'], user_price_dec());
			}
			$inv_no = add_supp_invoice($inv);
			commit_transaction(); // save PO+GRN+PI
			// FIXME payment for cash terms. (Needs cash account selection)
			unset($_SESSION['PO_req']);
			meta_forward($_SERVER['PHP_SELF'], "AddedPI=$inv_no");
		}
		else { // order modification

			$order_no = update_po_req($cart);

			unset($_SESSION['PO_req']);
			meta_forward($_SERVER['PHP_SELF'], "AddedID=$order_no&Updated=1");
		}
	}
}

//---------------------------------------------------------------------------------------------------
$id = find_submit('Delete');
if ($id != -1)
	handle_delete_item_repairing($id);

if (isset($_POST['Commit']))
{
	handle_commit_order_repairing();
}
if (isset($_POST['UpdateLine']))
	handle_update_item_repairing();

if (isset($_POST['EnterLine']))
	handle_add_new_item_repairing();

if (isset($_POST['CancelOrder']))
	handle_cancel_po_repairing();

if (isset($_POST['CancelUpdate']))
	unset_form_variables_repairing();

if (isset($_POST['CancelUpdate']) || isset($_POST['UpdateLine'])) {
	line_start_focus_repairing();
}

//---------------------------------------------------------------------------------------------------

start_form();



display_po_header_req($_SESSION['PO_req']);
echo "<br>";



display_po_items_req($_SESSION['PO_req']);

start_table(TABLESTYLE2);
textarea_row(_("Memo:"), 'Comments', null, 70, 4);

end_table(1);

div_start('controls', 'items_table');
$process_txt = _("Place Requisition");
$update_txt = _("Update Requisition");
$cancel_txt = _("Cancel Requisition");
if ($_SESSION['PO_req']->trans_type == ST_SUPPRECEIVE) {
	$process_txt = _("Process GRN");
	$update_txt = _("Update GRN");
	$cancel_txt = _("Cancel GRN");
}
elseif ($_SESSION['PO_req']->trans_type == ST_SUPPINVOICE) {
	$process_txt = _("Process Invoice");
	$update_txt = _("Update Invoice");
	$cancel_txt = _("Cancel Invoice");
}
if ($_SESSION['PO_req']->order_has_items())
{
	if($_GET['Type_rep']==48)
	submit_center_first('Commit', $process_txt, '', 'default');
	else if (   $_SESSION['PO_req']->order_no )

	submit_center_first('Commit', $update_txt, '', 'default');
	else
	submit_center_first('Commit', $process_txt, '', 'default');
	submit_center_last('CancelOrder', $cancel_txt);
}
else
	submit_center('CancelOrder', $cancel_txt, true, false, 'cancel');
div_end();
//---------------------------------------------------------------------------------------------------

end_form();
end_page();
?>
