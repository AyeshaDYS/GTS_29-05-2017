<?php

$page_security = 'SA_SALESAREA';

$path_to_root = "../..";

include($path_to_root . "/includes/session.inc");

page(_($help_context = "Edit Serial Number"));

include($path_to_root . "/includes/ui.inc");

simple_page_mode(true);

$name = $_GET['trans_no'];  
$stock_id = $_GET['stock_id'];  

function check_return ($name)
{
    echo "check function return name : <br>";
    return $name;
}

function update_serail ($serialnum,$transno,$name22)
{
    $validtaion_query = "SELECT count(serial_num) as sr,serial_num FROM  serial WHERE serial_num = '$serialnum' ";
    $validtaion_query_result = mysql_query($validtaion_query);
    $validtaion_query_myrow = db_fetch($validtaion_query_result);

    if($validtaion_query_myrow['sr'] > 0)
    {
        //echo " Duplication error! ";
        display_error(_("Duplication error!<br>Serial num is already exists."));
    }//Match Found
    else
    {
        $sql = "UPDATE serial SET serial_num=".db_escape($serialnum)."WHERE id=".db_escape($transno);
        db_query($sql,"The sales group could not be added");
        //echo " update function execute successfully ";
        display_notification(_("Update Successfully."));
            //refresh('../serial/test1.php');
            //echo "update function name : ". $name22."</br>";
    }	//else of dulplication execute
}

function refresh($loc)
{
    echo "<script>window.location.href='" . $loc . "'</script>";
}

$update = find_submit('Edit');
if($update != -1)
{
    update_serial_group($update, $_POST['sno'.$update]);
    display_notification(_($_POST['sno'.$update]." has been updated."));
}
$result = get_serial_groups($stock_id, $name);

start_table(TABLESTYLE, "width=30%");

$th = array(_("Serial#") ,_("Edit"));
inactive_control_column($th);

table_header($th);
$k = 0; 
start_form();
while ($myrow = db_fetch($result)) 
{
	alt_table_row_color($k);
	$_POST['sno'.$myrow["id"]] = $myrow["sr_no"];
	$serial = $myrow["id"];
	$tra = $myrow["trans_no"];
    //text_row_ex(_("Serial No:$serial"),'sno');
    start_row();
    text_cells(null,'sno'.$myrow["id"], null, 25, 15);
    edit_button_cell("Edit".$myrow["id"], _("Edit"));
    hidden("transno", $serial);
    hidden("name", $tra);
    end_row();
}
end_form();
end_table();
echo '<br>';

end_page();
?>