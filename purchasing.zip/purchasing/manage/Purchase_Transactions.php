<?php
$page_security = 'SA_CUSTOMER';
$path_to_root = "../..";

include($path_to_root . "/includes/db_pager.inc");
include_once($path_to_root . "/includes/session.inc");
$js = "";
if ($use_popup_windows)
	$js .= get_js_open_window(900, 500);
if ($use_date_picker)
	$js .= get_js_date_picker();

page(_($help_context = "Vehicle"), @$_REQUEST['popup'], false, "", $js);

include_once($path_to_root . "/includes/date_functions.inc");
include_once($path_to_root . "/includes/banking.inc");
include_once($path_to_root . "/includes/ui.inc");
include_once($path_to_root . "/includes/ui/contacts_view.inc");


if (isset($_GET['debtor_no']))
{
	$_POST['customer_id'] = $_GET['debtor_no'];
}

$selected_id = get_post('customer_id','');
//--------------------------------------------------------------------------------------------
function edit_link($row)
{
	return button("select", $row["order_no"], _("Edit"), ICON_ADD, 'selector' );
}
//--------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------- 
function get_colorname($row){
	return get_color_name($row['color']);
}
function fmt_supp($row){
	return get_supplier_name($row['supplier_id']);
}
function trans_view($trans)
{
	return get_trans_view_str(ST_PURCHORDER, $trans["order_no"]);
}

function customer_settings($selected_id)
{
	global $SysPrefs, $path_to_root, $auto_create_branch;

	if (!$selected_id)
	{

	}

	if (get_post('_search_on_changed') || get_post('_customer_type_changed') ) // enable/disable selection controls
	{
		$disable = get_post('search_on') !== '' || get_post('_customer_type_changed') != '';
		$Ajax->activate('orders_tbl');
	}
	//asad
	//$sql = get_sql_for_customer_view();
	$sql = "SELECT 	order_no,
					supplier_id, 
					reference, 
					supp_ref, 
					import_num, 
					pr_date, 
					gst_no1, 
					repairing_reference, 
					readyDate, 
					order_no 
			FROM ".TB_PREF."purch_orders ";
	if($_POST['customer_type'] != ALL_TEXT)
	{
		if($_POST['customer_type'] == 1) //reg	
			$sql .= " WHERE supp_ref LIKE  '%".$_POST['search_on']."%'";

		if($_POST['customer_type'] == 2) //reg	
			$sql .= " WHERE repairing_reference LIKE  '%".$_POST['search_on']."%'";

		if($_POST['customer_type'] == 3) //reg	
			$sql .= " WHERE import_num LIKE  '%".$_POST['search_on']."%'";

		if($_POST['customer_type'] == 4) //reg	
		{
			$sql .= " WHERE `reference` LIKE '%".$_POST['search_on']."%' ";
		}
		if($_POST['customer_type'] == 5) //Supplier
		{
			$sql_1 = " SELECT `supplier_id` FROM `".TB_PREF."suppliers` WHERE `supp_ref` LIKE '%".$_POST['search_on']."%' ";
			$res = db_query($sql_1, "Could not retrieve customers.");
			if (db_num_rows($res) > 0) {
				$deb_no = array();
				while ($myrow = db_fetch($res))
				{
					$deb_no[] = $myrow['supplier_id'];
				}
				//print_r($deb_no);
				$result = implode(',', $deb_no);
				$sql .= " WHERE supplier_id IN (" . $result . ")";
			}
		}
	}



	//else if( $_POST['customer_id'] != ALL_TEXT)
	//	$sql .= " WHERE id=".db_escape($_POST['customer_id']);trans_view

	//------------------------------------------------------------------------------------------------
	db_query("set @bal:=0");

	$cols = array(
		_("#") => array('align'=>'left', 'fun'=>'trans_view'),
		_("Supplier") => array('align'=>'left', 'fun'=>'fmt_supp'),
		_("Refernce"),
		_("Supp Reference"),// debtor_ref
		_("Import No."),
		_("PR Date"),
		_("PR Ref."),
		_("Repairing Ref"),
		_("Ready Date"),
		_("") =>	array('insert'=>true, 'fun'=>'edit_link'),

	);
	$table =& new_db_pager('trans_tbl', $sql, $cols);
	$table->width = "85%";
	display_db_pager($table);
}

//--------------------------------------------------------------------------------------------
//check_db_has_sales_types(_("There are no sales types defined. Please define at least one sales type before adding a customer."));
start_form();

//if (db_has_customers())
{
	start_table(TABLESTYLE_NOBORDER);
	start_row();
	hidden('customer_id');
	customer_db_filter_list_cells(_("Search On"), 'customer_type', null, "", "", false);
	ref_cells(_(""), 'search_on', '',null, '', true);
	submit_cells('RefreshInquiry', _("Show"),'',_('Refresh Inquiry'), 'default');
	end_row();
	end_table();
}

customer_settings($selected_id);

br();

hidden('popup', @$_REQUEST['popup']);
end_form();
end_page(false);

?>