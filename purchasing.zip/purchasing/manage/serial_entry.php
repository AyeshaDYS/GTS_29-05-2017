<?php
//bach up is on desktop/serial/test2.php
$page_security = 'SA_SUPPLIER';
$path_to_root = "../..";

include_once($path_to_root . "/includes/session.inc");
include_once($path_to_root . "/purchasing/includes/purchasing_ui.inc");
include_once($path_to_root . "/purchasing/includes/purchasing_db.inc");

page(_($help_context = "Serial No"));
simple_page_mode(true);

$ord_no = 1;
$type = $_GET['type']; 
$stock_id = $_GET['stock_id'];
$qty = $_GET['qty'];//Getting TRANS NO from TEST1.php
//-------------------------Functions-------------------------
function add_serail($name, $a, $stock, $loc_code)   //$name,$serialnum
{
    $validtaion_query = "SELECT count(id) FROM  ".TB_PREF."serial WHERE sr_no = '$a' ";
    $validtaion_query_result = db_query($validtaion_query);
    $validtaion_query_myrow = db_fetch($validtaion_query_result);

    if($validtaion_query_myrow['id'] > 0)
    {
      display_error(_("Duplication error!<br>Serial num is already exists."));
    }
    else
    {
        $sql = "INSERT INTO ".TB_PREF."serial ( ord_no, sr_no, stock_id, loc_code) VALUES (
        ".db_escape($name).",
        ".db_escape($a).",
        ".db_escape($stock).",
        ".db_escape($loc_code).")";
        db_query($sql,"The Serial ".$a."could not be added");
        //$a = mysql_insert_id();
        //if($a == true)
        //{
        //echo "id inserted";
        //}
        refresh('test1.php');
    }//elseif($validtaion_query_myrow['sr'] > 0)
}
function refresh($loc)
{
    echo "<script>window.location.href='".$loc."'</script>";
}
function update_serail($serialnum, $transno)
{
    echo "Update Successfully <br>";
    //echo $transno;
    $sql = "UPDATE serial SET serial_num=".db_escape($serialnum)."WHERE trans_no=".db_escape($transno);
    db_query($sql,"The sales group could not be added");
}
//------------------------------------Functions-----------------------------------------------------
if(isset($_POST['ADD_ITEM']))
{
    $input_error = 0;
//    $type = $_POST['type'];
//    $stock_id = $_POST['stock_id'];
//    $qty1 = $_POST['qty'];

    for($i = 1; $i <= $_POST['qty']; $i++)
    {
        if(strlen($_POST['serial_no'.$i]) == 0)
        {
            $input_error = 1;
            display_error(_("The fields cannot be empty".($_POST['sno'])));
            set_focus('serial_no'.$i);
        }
//        $res = check_dublication($_POST['serial_no'.$i], $_POST['stock_id']);
//        if($res > 0)
//        {
//            $input_error = 1;
//            display_error(_("This serial ".($_POST['serial_no'.$i])."already exists"));
//        }
    }
	if($input_error == 0)
	{

        for($i = 1; $i <= $_POST['qty']; $i++)
        {
            add_serial_group($_POST['type'], $_POST['trans_no'], $_POST['stock_id'], $_POST['serial_no'.$i], 'DEF');
        }
//        meta_forward($_SERVER['PHP_SELF'], "trans_no=".$_POST['trans_no']."&stock_id=".$_POST['stock_id']);
        display_notification(_("Serial number enter successfully"));
	}
}
$result2 = check_item_serial_existance($stock_id, $ord_no);

//if($result2 != '0')
//{
//    refresh($path_to_root.'/purchasing/manage/edit.php?trans_no='.$ord_no."&stock_id=".$stock_id);
//    //header('Location: ../serial/edit.php?trans_no='.$name);
//}
//else
{
  /*  if($type == 25)
    {
        $sql = "SELECT * FROM ".TB_PREF."grn_items 
                WHERE ".TB_PREF."grn_items.grn_batch_id = ".db_escape($ord_no)." 
                AND ".TB_PREF."grn_items.item_code = ".db_escape($stock_id);
        $result = db_query($sql, "Could not retrive Grn Item Details");
    }
    if($type == 17)
    {
        $sql = "SELECT * FROM ".TB_PREF."stock_moves 
        WHERE ".TB_PREF."stock_moves.trans_no= ".db_escape($ord_no)."
        AND ".TB_PREF."stock_moves.type = 17
        AND ".TB_PREF."stock_moves.stock_id= ".db_escape($stock_id);
        $result = db_query($sql, "Could not retrive Grn Item Details");
    }*/
    $result = get_serial_groups($_GET['stock_id'], $name);

    start_form(false, false, $_SERVER['PHP_SELF'] ."?trans_no=".$ord_no."&stock_id=".$stock_id);

    start_table(TABLESTYLE, "width=52%");

    $th = array(_("Serial#"), _("Quantity Rec"));

    table_header($th);

    $k = 0;

    if(db_num_rows($result) == 0)
    {
        for($r = 1; $r <= $qty; $r++)
        {
            hidden("qty", $_GET['qty']);
            hidden("stock_id", $_GET['stock_id']);
            hidden("type", $_GET['type']);
            text_row_ex(_("Serial No: ".$r), 'serial_no'.$r, 50);
        }
    }

//    for($r = 1; $r <= $qty; $r++ )
//    {
//        hidden("qty", $_GET['qty']);
//        hidden("stock_id", $_GET['stock_id']);
//        hidden("type", $_GET['type']);
//        text_row_ex(_("Serial No: ".$r), 'serial_no'.$r, 50);
//    }
    while($myrow = db_fetch($result))
    {
        alt_table_row_color($k);
        if($type == 25)
        {
            label_cell("Serial No: ".$myrow['id']);
            label_cell($myrow["sr_no"]);
            $loc = get_grn_batch($myrow["grn_batch_id"]); //asad 12-11-2014
            $rows =  $myrow["qty_recd"];
            $r;
            hidden("trans_no", $myrow["grn_batch_id"]);
            hidden("stock_id", $myrow["item_code"]);
            hidden("loc_code", $loc["loc_code"]);
            hidden("qty", $myrow["qty_recd"]);
            hidden("type", $type);
        }
        if($type == 17)
        {
            label_cell($myrow["trans_no"]);
            label_cell($myrow["qty"]);
            $loc = $myrow["loc_code"];
            $rows =  $myrow["qty"];
            $r;
            hidden("trans_no", $myrow["trans_no"]);
            hidden("stock_id", $myrow["stock_id"]);
            hidden("loc_code", $myrow["loc_code"]);
            hidden("qty", $myrow["qty"]);
            hidden("type", $type);
        }

    }
    end_table();
    // submit('submit', 'submit','.','image-button');
    echo "<br/>";
    submit_add_or_update_center(-1, '', 'both');
    end_table(1);
    end_form();
}
end_page();

?>