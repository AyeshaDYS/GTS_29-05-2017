function marked_all_checkbox(source) 
{

 
var str = source.name;
var res = str.substring(0, 6); 

checkboxes = document.getElementsByClassName('all_boxes');
    for(var i=0, n=checkboxes.length;i<n;i++) {
       checkboxes[i].checked = source.checked;
	set_value(checkboxes[i]);	
    }
}

function set_value(source){
	if(source.checked)	
	source.value = 1;
	else
	source.value = 0;	
}

