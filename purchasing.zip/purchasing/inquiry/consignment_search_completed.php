<?php
$page_security = 'SA_SUPPTRANSVIEW';
$path_to_root="../..";
include_once($path_to_root . "/includes/db_pager.inc");
include_once($path_to_root . "/includes/session.inc");

include_once($path_to_root . "/purchasing/includes/purchasing_ui.inc");
include_once($path_to_root . "/reporting/includes/reporting.inc");
if (!@$_GET['popup'])
{
	$js = "";
	if ($use_popup_windows)
		$js .= get_js_open_window(900, 500);
	if ($use_date_picker)
		$js .= get_js_date_picker();
	page(_($help_context = "Search Consignment status"), false, false, "", $js);
}
if (isset($_GET['order_number']))
{
	$order_number = $_GET['order_number'];
}

//-----------------------------------------------------------------------------------
// Ajax updates
//
if (get_post('SearchOrders'))
{
	$Ajax->activate('orders_tbl');
} elseif (get_post('_order_number_changed'))
{
	$disable = get_post('order_number') !== '';

	$Ajax->addDisable(true, 'OrdersAfterDate', $disable);
	$Ajax->addDisable(true, 'OrdersToDate', $disable);
	$Ajax->addDisable(true, 'StockLocation', $disable);
	$Ajax->addDisable(true, '_SelectStockFromList_edit', $disable);
	$Ajax->addDisable(true, 'SelectStockFromList', $disable);

	if ($disable) {
		$Ajax->addFocus(true, 'order_number');
	} else
		$Ajax->addFocus(true, 'OrdersAfterDate');

	$Ajax->activate('orders_tbl');
}
//---------------------------------------------------------------------------------------------

if (!@$_GET['popup'])
	start_form();

start_table(TABLESTYLE_NOBORDER);


date_cells(_("from:"), 'OrdersAfterDate', '', null, -30);
date_cells(_("to:"), 'OrdersToDate');
supplier_list_cells(_("Supplier:"), 'supplier_id', null, true, false, false, true);
transaction_series_list_cells("Transaction Series", 'transaction_series', null);
ref_cells(_("Required For:"), 'Required_For', '',null, '', true);
ref_cells(_("Supplier's Reference:"), 'Supplier_Reference', '',null, '', true);
ref_cells(_("Repairing Reference:"), 'Repairing_Reference', '',null, '', true);
ref_cells(_("Weight & Dimension:"), 'Weight_Dimension', '',null, '', true);
ref_cells(_("ETA:"), 'ETA', '',null, '', true);
ref_cells(_("ETD:"), 'ETD', '',null, '', true);
ref_cells(_("Freight Forwarder:"), 'Freight_Forwarder', '',null, '', true);
custom_gst_type_list_cells1(_("PO Type"), 'pr_type', null, '', '', false);
ref_cells(_("Import Number:"), 'Import_Number', '',null, '', true);
locations_list_cells(_("Receive Into:"), 'StkLocation', null, false, false);
Transaction_type_list_cells(_("Transaction Type:"),'transaction_type', null);
delivery_terms_list_cells(_("Delivery Terms:"), 'delivery_terms', null);
payment_terms_list_cells(_("Payment Terms:"), 'payment_terms', null);
material1_list_cells(_("Material Center:"), 'material_center', null, false, false, false, true);
shipmentmode_list_cells(_("Shipment Mode:"), 'shipment_mode', null);
status_type_list_cells(_("Status Type:"), 'status_type', null, true);
end_row();
start_row();
submit_cells('SearchOrders', _("Search"),'',_('Select documents'), 'default');
end_row();
end_table(1);
//---------------------------------------------------------------------------------------------
if (isset($_POST['order_number']))
{
	$order_number = $_POST['order_number'];
}

if (isset($_POST['SelectStockFromList']) &&	($_POST['SelectStockFromList'] != "") &&
	($_POST['SelectStockFromList'] != ALL_TEXT))
{
	$selected_stock_item = $_POST['SelectStockFromList'];
}
else
{
	unset($selected_stock_item);
}

//---------------------------------------------------------------------------------------------
function trans_view($trans)
{
	return get_supplier_trans_view_str(ST_CONSIGNMENT, $trans["order_no"]);
}

function edit_link($row)
{
	if (@$_GET['popup'])
		return '';
	return pager_link( _("Edit"),
		"/purchasing/po_entry_items1.php?" . SID
		. "ModifyOrderNumber=" . $row["order_no"], ICON_EDIT);
}

function prt_link($row)
{
	return print_document_link($row['order_no'], _("Print"), true, ST_CONSIGNMENT, ICON_PRINT);
}
//function get_transaction_series_name($t_type)
//{
//    if ($t_type['transaction_series'] == 0)
//        $name = "Supplies";
//    else
//        $name = "Services";
//    return $name;
//}
function systype_name($dummy, $type)
{
    global $systypes_array;
    return $systypes_array[$type];
}

function get_delivery_terms_name_for_dashboard($id)
{
    $sql = "SELECT terms 
 			FROM ".TB_PREF."delivery_terms 
 			WHERE terms_indicator = ".db_escape($id['delivery_terms']);
    $db = db_query($sql, "Error");
    $ft = db_fetch($db);
    return $ft[0];
}
function get_payment_terms_name_for_dashboard($id) {

    $sql = "SELECT terms FROM ".TB_PREF."payment_terms WHERE terms_indicator = ".db_escape($id['payment_terms']);
    $result = db_query($sql, "Could not find dimension");
    $row = db_fetch_row($result);
    return $row[0];
}
function get_material_centre_for_dasboard($id){
    $sql = "SELECT description FROM ".TB_PREF."material WHERE id = ".db_escape($id['material_centre']);
    $result = db_query($sql, "Could not find dimension");
    $row = db_fetch_row($result);
    return $row[0];
}
function get_shipment_mode_name_for_dashboard($id)
{
    $sql = "SELECT name 
 			FROM ".TB_PREF."shipmentmode 
 			WHERE id = ".db_escape($id['shipment_mode']);
    $db = db_query($sql, "Error");
    $ft = db_fetch($db);
    return $ft[0];
}
function get_status_type_name_for_dashboard($id) {

    $sql = "SELECT name 
			FROM ".TB_PREF."status_type 
			WHERE id = ".db_escape($id['status_type']);
    $result = db_query($sql, "Could not find dimension");
    $row = db_fetch_row($result);
    return $row[0];
}
//---------------------------------------------------------------------------------------------

$sql = get_sql_for_po_search_completed123($_POST['supplier_id'], $_POST['transaction_series'],
	$_POST['Required_For'], $_POST['Supplier_Reference'], $_POST['Repairing_Reference'],
	$_POST['Weight_Dimension'], $_POST['ETA'], $_POST['ETD'], $_POST['Freight_Forwarder'],
	$_POST['pr_type'], $_POST['Import_Number'], $_POST['StkLocation'], $_POST['transaction_type'],
	$_POST['delivery_terms'], $_POST['payment_terms'], $_POST['material_center'], $_POST['shipment_mode'],
	$_POST['status_type']);

$cols = array(
	_("#") => array('fun'=>'trans_view', 'ord'=>''),
	_("PO#") => array(/*'fun'=>'trans_view',*/ 'ord'=>''),
	_("PR#") => array(/*'fun'=>'trans_view',*/ 'ord'=>''),
	_("Supplier") => array('ord'=>''),
    _("Transaction Series") => array('fun'=>'get_transaction_series_name'),
	_("Required For"),
	_("Supplier's Reference"),
	_("Repairing Reference"),
	_("Ready Date") => array('name'=>'pr_date', 'type'=>'date', 'ord'=>''),
	_("Weight&Dimension"),
	_("ETA"),
	_("ETD"),
	_("Freight Forwarder"),
	_("PO Type") => array('fun'=>'systype_name'),
	_("Import number"),
	_("Delivery Date") => array('type'=>'date', 'ord'=>''),
	_("Order Date") => array('type'=>'date', 'ord'=>''),
	_("Receive Into"),
	_("Transaction Type") => array('fun'=>'get_transaction_type_name'),
	_("Arrival Date") => array('type'=>'date', 'ord'=>''),
	_("Delivery Terms") => array('fun'=>'get_delivery_terms_name_for_dashboard'),
	_("Payment Terms") => array('fun'=>'get_payment_terms_name_for_dashboard'),
	_("Material Center") => array('fun'=>'get_material_centre_for_dasboard'),
	_("Shipment Mode") => array('fun'=>'get_shipment_mode_name_for_dashboard'),
	_("Shipment Console"),
	_("Status Type") => array('fun'=>'get_status_type_name_for_dashboard'),
	_("Order Total") => 'amount',
	array('insert'=>true, 'fun'=>'edit_link'),
	array('insert'=>true, 'fun'=>'prt_link'),
);

if (get_post('StockLocation') != $all_items) {
	$cols[_("Location")] = 'skip';
}
//---------------------------------------------------------------------------------------------------

$table =& new_db_pager('orders_tbl', $sql, $cols);

$table->width = "80%";

display_db_pager($table);

if (!@$_GET['popup'])
{
	end_form();
	end_page();
}
?>
