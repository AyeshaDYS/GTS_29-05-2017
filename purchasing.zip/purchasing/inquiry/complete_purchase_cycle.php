<?php
$page_security = 'SA_SUPPTRANSVIEW';
$path_to_root="../..";
include_once($path_to_root . "/includes/db_pager.inc");
include_once($path_to_root . "/includes/session.inc");

include_once($path_to_root . "/purchasing/includes/purchasing_ui.inc");
include_once($path_to_root . "/reporting/includes/reporting.inc");

if (!@$_GET['popup'])
{
    $js = "";
    if ($use_popup_windows)
        $js .= get_js_open_window(900, 500);
    if ($use_date_picker)
        $js .= get_js_date_picker();
    page(_($help_context = "Search Complete Purchase Cycle"), false, false, "", $js);
}
//
function get_supp_invoice($Reference, $Supplier_DC_No, $BE_No, $Import_number)
{

	 $sql = " SELECT  
             grn.pr_no,
             grn.purch_order_no,
             grn.pr_no,
             grn.pr_no,
             grn.id,
             grn.reference,
             grn.invoice_due_date,
             grn.grn_no,
             grn.supp_dc_no,
             grn.supp_dc_date,
             grn.shipment_date,
             grn.shipment_console,
             grn.be_no,	
             grn.be_date,
             grn.supp_invoice_date,
             grn.shipment_date,
             grn.import_number,
             grn.be_date,
             line.cost_centre
	FROM ".TB_PREF."grn_items as line,
         ".TB_PREF."grn_batch as grn";

    $data_after = date2sql($_POST['OrdersAfterDate']);
    $date_before = date2sql($_POST['OrdersToDate']);

    $sql .= " WHERE grn.shipment_date >= '$data_after'";
    $sql .= " AND grn.shipment_date <= '$date_before'";

    if ($Reference != "")
    {
        $number_like = "%".$Reference."%";
        $sql .= " AND grn.reference LIKE ".db_escape($number_like);
    }
    if ($Supplier_DC_No != "")
    {
        $number_like = "%".$Supplier_DC_No."%";
        $sql .= " AND grn.supp_dc_no LIKE ".db_escape($number_like);
    }
    if ($BE_No != "")
    {
        $number_like = "%".$BE_No."%";
        $sql .= " AND grn.be_no LIKE ".db_escape($number_like);
    }
    if ($BE_No != "")
    {
        $number_like = "%".$BE_No."%";
        $sql .= " AND grn.be_no LIKE ".db_escape($number_like);
    }
    if ($Import_number != "")
    {
        $number_like = "%".$Import_number."%";
        $sql .= " AND grn.import_number LIKE ".db_escape($number_like);
    }

    $sql .= " GROUP BY grn.pr_no";

	return $sql;
}
function get_sql_for_complete_cycle_search()
{
	global $order_number, $selected_stock_item;;

	$sql = "SELECT 
		porder.order_no, 
		porder.reference, 
		supplier.supp_name, 
		location.location_name,
		porder.requisition_no, 
		porder.pr_date, 
		supplier.curr_code, 
		Sum(line.unit_price*line.quantity_ordered) AS OrderValue,
		porder.into_stock_location,
		supplier.supplier_id
		FROM ".TB_PREF."purch_requisition as porder, "
		.TB_PREF."purch_requisition_details as line, "
		.TB_PREF."suppliers as supplier, "
		.TB_PREF."locations as location
		WHERE porder.order_no = line.order_no
		AND porder.supplier_id = supplier.supplier_id
		 ";

	if (isset($_GET['supplier_id']))
		$sql .= "AND supplier.supplier_id=".@$_GET['supplier_id']." ";
	if (isset($order_number) && $order_number != "")
	{
		$sql .= "AND porder.reference LIKE ".db_escape('%'. $order_number . '%');
	}
	else
	{

		$data_after = date2sql($_POST['OrdersAfterDate']);
		$date_before = date2sql($_POST['OrdersToDate']);

		$sql .= " AND porder.pr_date >= '$data_after'";
		$sql .= " AND porder.pr_date <= '$date_before'";

		if (isset($_POST['StockLocation']) && $_POST['StockLocation'] != ALL_TEXT)
		{
			$sql .= " AND porder.into_stock_location = ".db_escape($_POST['StockLocation']);
		}
		if (isset($selected_stock_item))
		{
			$sql .= " AND line.item_code=".db_escape($selected_stock_item);
		}

	} //end not order number selected

	$sql .= " GROUP BY porder.order_no";
	return $sql;
}//


//if (isset($_GET['order_number']))
//{
//	$order_number = $_GET['order_number'];
//}

//-----------------------------------------------------------------------------------
// Ajax updates
//
if (get_post('SearchOrders'))
{
	$Ajax->activate('orders_tbl');
} elseif (get_post('_order_number_changed'))
{
	$disable = get_post('order_number') !== '';

	$Ajax->addDisable(true, 'OrdersAfterDate', $disable);
	$Ajax->addDisable(true, 'OrdersToDate', $disable);
	$Ajax->addDisable(true, 'StockLocation', $disable);
	$Ajax->addDisable(true, '_SelectStockFromList_edit', $disable);
	$Ajax->addDisable(true, 'SelectStockFromList', $disable);

	if ($disable) {
		$Ajax->addFocus(true, 'order_number');
	} else
		$Ajax->addFocus(true, 'OrdersAfterDate');

	$Ajax->activate('orders_tbl');
}
//---------------------------------------------------------------------------------------------

if (!@$_GET['popup'])
	start_form();

start_table(TABLESTYLE_NOBORDER);
start_row();
//ref_cells(_("#:"), 'order_number', '',null, '', true);

date_cells(_("from:"), 'OrdersAfterDate', '', null, -30);
date_cells(_("to:"), 'OrdersToDate');
ref_cells(_("Reference:"), 'Reference', '',null, '', true);
ref_cells(_("Supplier DC No."), 'Supplier_DC_No', '',null, '', true);
ref_cells(_("BE No."), 'BE_No', '',null, '', true);
ref_cells(_("Import number:"), 'Import_number', '',null, '', true);
submit_cells('SearchOrders', _("Search"),'',_('Select documents'), 'default');
//locations_list_cells(_("into location:"), 'StockLocation', null, true);
end_row();
end_table();

//start_table(TABLESTYLE_NOBORDER);
//start_row();

//stock_items_list_cells(_("for item:"), 'SelectStockFromList', null, true);


//end_row();

end_table(1);

//---------------------------------------------------------------------------------------------
if (isset($_POST['order_number']))
{
	$order_number = $_POST['order_number'];
}

if (isset($_POST['SelectStockFromList']) &&	($_POST['SelectStockFromList'] != "") &&
	($_POST['SelectStockFromList'] != ALL_TEXT))
{
	$selected_stock_item = $_POST['SelectStockFromList'];
}
else
{
	unset($selected_stock_item);
}

//---------------------------------------------------------------------------------------------
function trans_view($trans)
{
	return get_trans_view_str(ST_SUPPINVOICE, $trans["pr_no"]);
}

function trans_view_for_requisition($trans)
{
	return get_trans_view_str(ST_PURCHASEREQUISITION, $trans["pr_no"]);
}

function trans_view_for_grn($trans)
{
	return get_trans_view_str(ST_SUPPRECEIVE, $trans["pr_no"]);
}

function trans_view_for_purchase_order($trans)
{
	return get_trans_view_str(ST_PURCHORDER, $trans["purch_order_no"]);
}



//function edit_link($row)
//{
//	if (@$_GET['popup'])
//		return '';
//	return pager_link( _("Edit"),
//		"/purchasing/po_entry_items1.php?" . SID
//		. "ModifyOrderNumber=" . $row["order_no"], ICON_EDIT);
//}



function edit_link($row)
{
	if (@$_GET['popup'])
		return '';
	return pager_link( _("Edit"),
		"/purchasing/purchasereq.php?" . SID
		. "ModifyOrderNumber=" . $row["order_no"], ICON_EDIT);
}

function prt_link($row)
{
	return print_document_link($row['order_no'], _("Print"), true, 18, ICON_PRINT);
}

if (isset($_POST['BatchInvoice']))
{
	// checking batch integrity
	$del_count = 0;
	foreach($_POST['Sel_'] as $delivery => $branch) {
		$checkbox = 'Sel_'.$delivery;
		if(check_value($checkbox))	{
			if(!$del_count) {
				$del_branch = $branch;
			}
			else {
				if ($del_branch != $branch)	{
					$del_count=0;
					break;
				}
			}
			$selected[] = $delivery;
			$del_count++;
		}
	}

	if (!$del_count) {
		display_error(_('For batch invoicing you should select at least one delivery. All items must be dispatched to the same customer branch.'));
	} else {
		$_SESSION['DeliveryBatch'] = $selected;
		meta_forward($path_to_root . '/purchasing/po_entry_items1.php','BatchOrder=Yes');
	}
}

function batch_checkbox($row)
{
	$name = "Sel_" .$row['order_no'];
	return $row['Done'] ? '' :
		"<input type='checkbox' name='$name' value='1' >"
// add also trans_no => branch code for checking after 'Batch' submit
		."<input name='Sel_[".$row['order_no']."]' type='hidden' value='"
		.$row['supplier_id']."'>\n";
	
}

//---------------------------------------------------------------------------------------------

$sql = get_supp_invoice($_POST['Reference'], $_POST['Supplier_DC_No'], $_POST['BE_No'], $_POST['Import_number']);

$cols = array(
	_("Requesition") => array('fun'=>'trans_view_for_requisition', 'ord'=>''),
	_("PO") => array('fun'=>'trans_view_for_purchase_order', 'ord'=>''),
	_("GRN") => array('fun'=>'trans_view_for_grn', 'ord'=>''),
	_("Ivoice") => array('fun'=>'trans_view', 'ord'=>''),
	_("PR Number"),
	_("Reference"),
	_("Invoice due date") => array('type'=>'date', 'ord'=>''),
	_("GRN No"),
	_("Supplier DC No") ,
	_("Supplier DC Date") => array('type'=>'date', 'ord'=>''),
	_("Shipment Date") => array('type'=>'date', 'ord'=>''),
	_("Shipment Console"),
	_("BE No") ,
	_("BE Date") ,
	_("Supplier Invoice Date") => array('type'=>'date', 'ord'=>''),
	_("Shipment Date") => array('type'=>'date', 'ord'=>''),
	_("Cost Center") ,
	_("Import number"),
	_("Payment Date") => array('type'=>'date', 'ord'=>''),
);
if (get_post('StockLocation') != $all_items) {
	$cols[_("Location")] = 'skip';
}
//---------------------------------------------------------------------------------------------------
if (isset($_SESSION['Batch']))
{
	foreach($_SESSION['Batch'] as $trans=> $del)
		unset($_SESSION['Batch'][$trans]);
	unset($_SESSION['Batch']);
}



$table =& new_db_pager('orders_tbl', $sql, $cols);

$table->width = "80%";

display_db_pager($table);

if (!@$_GET['popup'])
{
	end_form();
	end_page();
}
?>