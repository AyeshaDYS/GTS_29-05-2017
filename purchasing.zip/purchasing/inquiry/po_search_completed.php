<?php

$page_security = 'SA_SUPPTRANSVIEW';
$path_to_root="../..";
include_once($path_to_root . "/includes/db_pager.inc");
include_once($path_to_root . "/includes/session.inc");

include_once($path_to_root . "/purchasing/includes/purchasing_ui.inc");
include_once($path_to_root . "/reporting/includes/reporting.inc");

if (!@$_GET['popup'])
{
	$js = "";
	if ($use_popup_windows)
		$js .= get_js_open_window(900, 500);
	if ($use_date_picker)
		$js .= get_js_date_picker();
	page(_($help_context = "Search Purchase Orders"), false, false, "", $js);
}
//if (isset($_GET['order_number']))
//{
//	$order_number = $_GET['order_number'];
//}

//-----------------------------------------------------------------------------------
// Ajax updates
//
if (get_post('SearchOrders'))
{
	$Ajax->activate('orders_tbl');
} elseif (get_post('_order_number_changed'))
{
	$disable = get_post('order_number') !== '';

	$Ajax->addDisable(true, 'OrdersAfterDate', $disable);
	$Ajax->addDisable(true, 'OrdersToDate', $disable);
	$Ajax->addDisable(true, 'StockLocation', $disable);
	$Ajax->addDisable(true, '_SelectStockFromList_edit', $disable);
	$Ajax->addDisable(true, 'SelectStockFromList', $disable);

	if ($disable) {
		$Ajax->addFocus(true, 'order_number');
	} else
		$Ajax->addFocus(true, 'OrdersAfterDate');

	$Ajax->activate('orders_tbl');
}
//---------------------------------------------------------------------------------------------

if (!@$_GET['popup'])
	start_form();

start_table(TABLESTYLE_NOBORDER);
start_row();

date_cells(_("from:"), 'OrdersAfterDate', '', null, -30);
date_cells(_("to:"), 'OrdersToDate');
ref_cells(_("Required For:"), 'Required_For', '',null, '', true);
ref_cells(_("Reference:"), 'Reference', '',null, '', true);
import_number_list_cells(_("Import number:"), 'import_num', null);
ref_cells(_("Supplier's Reference:"), 'Supplier_Reference', '',null, '', true);
ref_cells(_("Repairing Reference:"), 'Repairing_Reference', '',null, '', true);
ref_cells(_("Order Acknowledgment:"), 'Order_Acknowledgment', '',null, '', true);
payment_terms_list_cells(_("Payment Terms:"), 'payment_terms', null);
transaction_series_list_cells("Transaction Series", 'transaction_series', null);
Transaction_type_list_cells(_("Transaction Type:"),'transaction_type', null);
supplier_list_cells(_("Supplier:"), 'supplier_id', null, true, false, false, true);
custom_gst_type_list_cells1(_("PO Type"), 'pr_type', null, '', '', false);
locations_list_cells(_("Receive Into:"), 'StkLocation', null, false, false);
material1_list_cells(_("Material Center:"), 'material_center', null, false, false, false, true);
shipmentmode_list_cells(_("Shipment Mode:"), 'shipment_mode', null);
acknowledgment_status_list_cells(_("Acknowledgment Status:"), 'acknowledge_status', null);
delivery_terms_list_cells(_("Delivery Terms:"), 'delivery_terms', null);

end_row();
//start_table(TABLESTYLE_NOBORDER);
start_row();
submit_cells('SearchOrders', _("Search"),'',_('Select documents'), 'default');
end_row();

end_table(1);
//---------------------------------------------------------------------------------------------
if (isset($_POST['order_number']))
{
	$order_number = $_POST['order_number'];
}

if (isset($_POST['SelectStockFromList']) &&	($_POST['SelectStockFromList'] != "") &&
	($_POST['SelectStockFromList'] != ALL_TEXT))
{
	$selected_stock_item = $_POST['SelectStockFromList'];
}
else
{
	unset($selected_stock_item);
}

//---------------------------------------------------------------------------------------------
function trans_view($trans)
{
	return get_supplier_trans_view_str(ST_PURCHORDER, $trans["order_no"]);
}
function pr_view($trans)
{
	return get_trans_view_str(ST_PURCHASEREQUISITION,  $trans['pr_no']);
}

function edit_link($row)
{
	if (@$_GET['popup'])
		return '';
	return pager_link(_("Edit"),
		"/purchasing/po_entry_items1.php?" . SID
		. "ModifyOrderNumber=" . $row["order_no"], ICON_EDIT);
}



function edit_link1($row)
{
	$result = check_po_for_edit($row['order_no']);

	if($result)
	{
		return null;
	}
	else
	{
		return pager_link(_("Edit"), "/purchasing/po_entry_items.php?".SID."ModifyOrderNumber=".$row["order_no"], ICON_EDIT);
	}
}

function prt_link($row)
{
	return print_document_link($row['order_no'], _("Print"), true, 18, ICON_PRINT);
}
function claim_link($row)
{
	$result = check_warranty_claim($row['order_no']);
	if($result)
		return null;
	else
		return pager_link( _("Receive"), "/purchasing/warranty_claim.php?Type=" .ST_PURCHORDER ."&". "WarrantyClaim=" . $row["order_no"], ICON_RECEIVE);
}

function receive_link($row)
{
	return pager_link( _("Receive"),
		"/purchasing/po_receive_items_consignment.php?PONumber=" . $row["order_no"]."&Type2=".ST_PURCHORDER, ICON_RECEIVE);
}
function consign_link($row)
{
	return pager_link( _("Consign"),
		"/purchasing/po_entry_items1.php?AddOrder=" . $row["order_no"]."&Type2=".ST_CONSIGNMENT, ICON_RECEIVE);
}

if (isset($_POST['BatchInvoice']))
{
	// checking batch integrity
	$del_count = 0;
	foreach($_POST['Sel_'] as $delivery => $branch) {


		$checkbox = 'Sel_'.$delivery;
		if(check_value($checkbox))	{
			if(!$del_count) {
				$del_branch = $branch;
			}
			else {
				if ($del_branch != $branch)	{
					$del_count=0;
					break;
				}
			}
			$selected[] = $delivery;
			$del_count++;
		}
	}

	if (!$del_count) {
		display_error(_('For batch invoicing you should select at least one delivery. All items must be dispatched to the same Supplier.'));
	} else {
		$_SESSION['DeliveryBatch'] = $selected;
		meta_forward($path_to_root . '/purchasing/supplier_invoice_consignment.php','BatchOrder=Yes');
	}
}

function batch_checkbox($row)
{
	$result=check_po_for_batch($row['order_no']);

	if($result)
	{
		return null;
	}
	else {
		$name = "Sel_" . $row['order_no'];
		return $row['Done'] ? '' :
			"<input type='checkbox' name='$name' value='1' >"
	// add also trans_no => branch code for checking after 'Batch' submit
			. "<input name='Sel_[" . $row['order_no'] . "]' type='hidden' value='"
			. $row['supplier_id'] . "'>\n";
	}

}
//function get_transaction_series_name($t_type)
//{
//    if ($t_type['transaction_series'] == 0)
//        $name = "Supplies";
//    else
//        $name = "Services";
//    return $name;
//}

function get_payment_terms_name_for_dashboard($id) {

    $sql = "SELECT terms FROM ".TB_PREF."payment_terms WHERE terms_indicator = ".db_escape($id['payment_terms']);
    $result = db_query($sql, "Could not find dimension");
    $row = db_fetch_row($result);
    return $row[0];
}
function systype_name($dummy, $type)
{
    global $systypes_array;
    return $systypes_array[$type];
}
function get_material_centre_for_dashboard($id){
    $sql = "SELECT description FROM ".TB_PREF."material WHERE id = ".db_escape($id['material_centre']);
    $result = db_query($sql, "Could not find dimension");
    $row = db_fetch_row($result);
    return $row[0];
}
function get_shipment_mode_name_for_dashboard($id)
{
    $sql = "SELECT name 
 			FROM ".TB_PREF."shipmentmode 
 			WHERE id = ".db_escape($id['shipment_mode']);
    $db = db_query($sql, "Error");
    $ft = db_fetch($db);
    return $ft[0];
}
function get_acknowledgment_status_name($acknowledgment_status)
{
    $sql = "SELECT name FROM ".TB_PREF."acknowledgment_status WHERE id=".db_escape($acknowledgment_status['acknowledge_status']);

    $result = db_query($sql,"could not get area");
    $fetch = db_fetch_row($result);
	return $fetch[0];
}
function get_shipment_console_name_for_dashboard($id){

    $sql = "SELECT name FROM ".TB_PREF."shipment_consol  WHERE id = ".db_escape($id['shipment_consol']);
    $result = db_query($sql, "Could not find dimension");
    $row = db_fetch_row($result);
    return $row[0];

}
function get_delivery_terms_name_for_dashboard($id)
{
    $sql = "SELECT terms 
 			FROM ".TB_PREF."delivery_terms 
 			WHERE terms_indicator = ".db_escape($id['delivery_terms']);
    $db = db_query($sql, "Error");
    $ft = db_fetch($db);
    return $ft[0];
}


//---------------------------------------------------------------------------------------------
$sql = get_sql_for_po_search($_POST['Required_For'], $_POST['Import_Number'],
	$_POST['transaction_series'], $_POST['supplier_id'], $_POST['Reference'],
	$_POST['transaction_type'], $_POST['payment_terms'], $_POST['pr_type'],
	$_POST['Supplier_Reference'], $_POST['Repairing_Reference'], $_POST['StkLocation'],
	$_POST['material_center'], $_POST['shipment_mode'], $_POST['acknowledge_status'],
    $_POST['Order_Acknowledgment'], $_POST['delivery_terms']);

$cols = array(
	_("#") => array('fun'=>'trans_view', 'ord'=>''),
	_("PR#") => array('fun'=>'pr_view', 'ord'=>''),
	_("Required For"),
	_("Import Number"),
	_("Transaction Series") => array('fun'=>'get_transaction_series_name'),
	_("Supplier") => array('ord'=>''),
	_("Reference"),
    _("Transaction Type") => array('fun'=>'get_transaction_type_name'),
	_("Payment Terms") => array('fun'=>'get_payment_terms_name_for_dashboard'),
	_("PO Type") => array('fun'=>'systype_name'),
	_("Supplier's Reference") => array('align'=>'center'),
	_("Repairing Reference") => array('align'=>'center'),
	_("Receive Into"),
	_("Material Center") => array('fun'=>'get_material_centre_for_dashboard'),
	_("Order Date") => array('type' => 'date', 'ord' => ''),
	_("Delivery Date") => array('type' => 'date', 'ord' => ''),
	_("Shipment Mode") => array('fun'=>'get_shipment_mode_name_for_dashboard'),
	_("Acknowledgment Status") => array('fun'=>'get_acknowledgment_status_name'),
	_("Order Acknowledgment"),
	_("Acknowledgment Date") => array('type' => 'date', 'ord' => ''),
	_("Shipment Console") => array(),
	_("Delivery Terms") => array('fun'=>'get_delivery_terms_name_for_dashboard'),
//	_("Status Type") => array('fun'=>'get_delivery_terms_name_for_dashboard'),
	_("Order Total") => 'amount',
	submit('BatchInvoice',_("Consignment Batch"), false, _("Batch Invoicing"))
	=> array('insert'=>true, 'fun'=>'batch_checkbox', 'align'=>'center'),
	array('insert'=>true, 'fun'=>'edit_link1'),
	array('insert'=>true, 'fun'=>'prt_link'),
	_("Consignment") =>array('insert'=>true, 'fun'=>'consign_link'),
	_("GRN") =>array('insert'=>true, 'fun'=>'receive_link')

);

if (get_post('StockLocation') != $all_items) {
	$cols[_("Location")] = 'skip';
}
//---------------------------------------------------------------------------------------------------

if (isset($_SESSION['Batch']))
{
	foreach($_SESSION['Batch'] as $trans=> $del)
		unset($_SESSION['Batch'][$trans]);
	unset($_SESSION['Batch']);
}

$table =& new_db_pager('orders_tbl', $sql, $cols);

$table->width = "80%";

display_db_pager($table);

if (!@$_GET['popup'])
{
	end_form();
	end_page();
}
?>
