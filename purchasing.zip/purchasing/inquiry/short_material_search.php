<?php
$page_security = 'SA_SUPPTRANSVIEW';
$path_to_root="../..";
include_once($path_to_root . "/includes/db_pager.inc");
include_once($path_to_root . "/includes/session.inc");

include_once($path_to_root . "/purchasing/includes/purchasing_ui.inc");
include_once($path_to_root . "/reporting/includes/reporting.inc");
if (!@$_GET['popup'])
{
	$js = "";
	if ($use_popup_windows)
		$js .= get_js_open_window(900, 500);
	if ($use_date_picker)
		$js .= get_js_date_picker();
	page(_($help_context = "Search Claim For Short Material"), false, false, "", $js);
}
if (isset($_GET['order_number']))
{
	$order_number = $_GET['order_number'];
}

//-----------------------------------------------------------------------------------
// Ajax updates
//
if (get_post('SearchOrders')) 
{
	$Ajax->activate('orders_tbl');
} elseif (get_post('_order_number_changed')) 
{
	$disable = get_post('order_number') !== '';

	$Ajax->addDisable(true, 'OrdersAfterDate', $disable);
	$Ajax->addDisable(true, 'OrdersToDate', $disable);
	$Ajax->addDisable(true, 'StockLocation', $disable);
	$Ajax->addDisable(true, '_SelectStockFromList_edit', $disable);
	$Ajax->addDisable(true, 'SelectStockFromList', $disable);

	if ($disable) {
		$Ajax->addFocus(true, 'order_number');
	} else
		$Ajax->addFocus(true, 'OrdersAfterDate');

	$Ajax->activate('orders_tbl');
}
//---------------------------------------------------------------------------------------------

if (!@$_GET['popup'])
	start_form();

start_table(TABLESTYLE_NOBORDER);
start_row();
//ref_cells(_("#:"), 'order_number', '',null, '', true);

date_cells(_("from:"), 'OrdersAfterDate', '', null, -30);
date_cells(_("to:"), 'OrdersToDate');
ref_cells(_("Import Number:"), 'Import_Number', '',null, '', true);
ref_cells(_("Supplier Invoice No:"), 'Supplier_Invoice_No', '',null, '', true);
ref_cells(_("Supplier DC No:"), 'Supplier_DC_No', '',null, '', true);
ref_cells(_("Claimed item GRN:"), 'Claimed_item_GRN', '',null, '', true);
transaction_series_list_cells("Transaction Series", 'transaction_series', null);
Transaction_type_list_cells(_("Transaction Type:"),'transaction_type', null);
supplier_list_cells(_("Supplier:"), 'supplier_id', null, false, false, false, true);
ref_cells(_("Reference:"), 'Reference', '',null, '', true);
ref_cells(_("GRN Book No:"), 'GRN_Book_No', '',null, '', true);
grn_type_list_cells(_("GRN Type"), 'grn_type', null);
stock_status_list_cells(_("Stock Status:"), 'stock_status', null);
claim_status_list_cells(_("Claim Status:"), 'claim_status', null);
material1_list_cells(_("Material Center:"), 'material_center', null, false, false, false, true);
delivery_terms_list_cells(_("Delivery Terms:"), 'delivery_terms', null);
shipmentmode_list_cells(_("Shipment Mode:"), 'shipment_mode', null);

start_row();
submit_cells('SearchOrders', _("Search"),'',_('Select documents'), 'default');
end_row();
end_table();
end_table(1);
//---------------------------------------------------------------------------------------------
if (isset($_POST['order_number']))
{
	$order_number = $_POST['order_number'];
}

if (isset($_POST['SelectStockFromList']) &&	($_POST['SelectStockFromList'] != "") &&
	($_POST['SelectStockFromList'] != ALL_TEXT))
{
 	$selected_stock_item = $_POST['SelectStockFromList'];
}
else
{
	unset($selected_stock_item);
}

//---------------------------------------------------------------------------------------------
function trans_view($trans)
{
	return get_supplier_trans_view_str(ST_CLAIMSHORTMATERIAL, $trans["order_no"]);

}

function edit_link($row) 
{
	if (@$_GET['popup'])
		return '';
  	return pager_link( _("Edit"),
		"/purchasing/claimforshortmaterial.php?" . SID
		."ModifyOrderNumber=".$row["order_no"]."&grn_no=".$row["grn_no"], ICON_EDIT);
}

function prt_link($row)
{
	return print_document_link($row['order_no'], _("Print"), true, ST_CLAIMSHORTMATERIAL, ICON_PRINT);
}
//function get_transaction_series_name($t_type)
//{
//    if ($t_type['transaction_series'] == 0)
//        $name = "Supplies";
//    else
//        $name = "Services";
//    return $name;
//}

function get_grn_type_name_for_dashboard($id){
    $sql = "SELECT description FROM ".TB_PREF."grn_type WHERE id = ".db_escape($id['grn_type']);
    $result = db_query($sql, "Could not find dimension");
    $row = db_fetch_row($result);
    return $row[0];
}
function get_stock_status_name_for_dashboard($id)
{
    $sql = "SELECT description FROM ".TB_PREF."stock_status WHERE id = ".db_escape($id['stock_status']);
    $result= db_query($sql,"could not get areas");
    $row=db_fetch_row($result);
    return $row[0];
}
function get_claim_status_name_for_dashboard($id)
{
    $sql = "SELECT description FROM ".TB_PREF."claim_status WHERE id = ".db_escape($id['claim_status']);
    $result= db_query($sql,"could not get areas");
    $row=db_fetch_row($result);
    return $row[0];
}
function get_material_centre_for_dashboard($id){
    $sql = "SELECT description FROM ".TB_PREF."material WHERE id = ".db_escape($id['material_centre']);
    $result = db_query($sql, "Could not find dimension");
    $row = db_fetch_row($result);
    return $row[0];
}
function get_delivery_terms_name_for_dashboard($id)
{
    $sql = "SELECT terms 
 			FROM ".TB_PREF."delivery_terms 
 			WHERE terms_indicator = ".db_escape($id['delivery_terms']);
    $db = db_query($sql, "Error");
    $ft = db_fetch($db);
    return $ft[0];
}
function get_shipment_mode_name_for_dashboard($id)
{
    $sql = "SELECT name 
 			FROM ".TB_PREF."shipmentmode 
 			WHERE id = ".db_escape($id['shipment_mode']);
    $db = db_query($sql, "Error");
    $ft = db_fetch($db);
    return $ft[0];
}
function pr_view($trans)
{
    return get_trans_view_str(ST_PURCHASEREQUISITION,  $trans['pr_no']);
}
function po_view($trans)
{
    return get_trans_view_str(ST_PURCHORDER,  $trans['purchase_id']);
}
function grn_view($trans)
{
    return get_trans_view_str(ST_SUPPRECEIVE,  $trans['grn_no']);
}
//---------------------------------------------------------------------------------------------

$sql = get_short_material_claim($_POST['Import_Number'], $_POST['transaction_series'],
	$_POST['transaction_type'], $_POST['supplier_id'], $_POST['Reference'], $_POST['GRN_Book_No'],
	$_POST['grn_type'], $_POST['stock_status'], $_POST['claim_status'], $_POST['Supplier_Invoice_No'],
	$_POST['Supplier_DC_No'], $_POST['Claimed_item_GRN'], $_POST['material_center'],
	$_POST['delivery_terms'], $_POST['shipment_mode']);

$cols = array(
	_("#") => array('fun'=>'trans_view', 'ord'=>''),
	_("PR#") => array('fun'=>'pr_view', 'ord'=>''),
	_("PO#") => array('fun'=>'po_view', 'ord'=>''),
	_("GRN No#") => array('fun'=>'grn_view', 'ord'=>''),
	_("Short Quantity"),
	_("GRN Quantity"),
	_("Import number"),
    _("Transaction Series") => array('fun'=>'get_transaction_series_name'),
    _("Transaction Type") => array('fun'=>'get_transaction_type_name'),
	_("Supplier") => array('ord'=>''),
    _("Reference"),
    _("GRN Book No#"),
    _("GRN Type") => array('fun'=>'get_grn_type_name_for_dashboard'),
    _("Stock Status") => array('fun'=>'get_stock_status_name_for_dashboard'),
    _("Claim Status") => array('fun'=>'get_claim_status_name_for_dashboard'),
	_("Shipment Console"),
	_("Supplier Invoice No"),
	_("Supplier DC No"),
	_("PO Date") => array('type'=>'date', 'ord'=>''),
	_("Supplier Invoice Date") => array('type'=>'date', 'ord'=>''),
	_("Claimed item GRN"),
    _("Material Centre") => array('fun'=>'get_material_centre_for_dashboard'),
    _("Supplier DC Date") => array('type'=>'date', 'ord'=>''),
    _("Shipment Date") => array('type'=>'date', 'ord'=>''),
    _("Claim item Date") => array('type'=>'date', 'ord'=>''),
    _("Delivery Terms") => array('fun'=>'get_delivery_terms_name_for_dashboard'),
    _("Shipment Mode") => array('fun'=>'get_shipment_mode_name_for_dashboard'),
	array('insert'=>true, 'fun'=>'edit_link'),
	array('insert'=>true, 'fun'=>'prt_link'),
	array('insert'=>true, 'fun'=>'receive_link')
);

if (get_post('StockLocation') != $all_items) {
	$cols[_("Location")] = 'skip';
}
//---------------------------------------------------------------------------------------------------

$table =& new_db_pager('orders_tbl', $sql, $cols);

$table->width = "80%";

display_db_pager($table);

if (!@$_GET['popup'])
{
	end_form();
	end_page();
}	
?>
