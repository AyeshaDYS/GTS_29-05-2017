<?php
$page_security = 'SA_SUPPTRANSVIEW';
$path_to_root="../..";
include_once($path_to_root . "/includes/db_pager.inc");
include_once($path_to_root . "/includes/session.inc");

include_once($path_to_root . "/purchasing/includes/purchasing_ui.inc");
include_once($path_to_root . "/reporting/includes/reporting.inc");
if (!@$_GET['popup'])
{
	$js = "";
	if ($use_popup_windows)
		$js .= get_js_open_window(900, 500);
	if ($use_date_picker)
		$js .= get_js_date_picker();
	page(_($help_context = "Search Warranty Claim"), false, false, "", $js);
}
if (isset($_GET['order_number']))
{
	$order_number = $_GET['order_number'];
}

//-----------------------------------------------------------------------------------
// Ajax updates
//
if (get_post('SearchOrders')) 
{
	$Ajax->activate('orders_tbl');
} elseif (get_post('_order_number_changed')) 
{
	$disable = get_post('order_number') !== '';

	$Ajax->addDisable(true, 'OrdersAfterDate', $disable);
	$Ajax->addDisable(true, 'OrdersToDate', $disable);
	$Ajax->addDisable(true, 'StockLocation', $disable);
	$Ajax->addDisable(true, '_SelectStockFromList_edit', $disable);
	$Ajax->addDisable(true, 'SelectStockFromList', $disable);

	if ($disable) {
		$Ajax->addFocus(true, 'order_number');
	} else
		$Ajax->addFocus(true, 'OrdersAfterDate');

	$Ajax->activate('orders_tbl');
}
//---------------------------------------------------------------------------------------------

if (!@$_GET['popup'])
	start_form();

start_table(TABLESTYLE_NOBORDER);
start_row();
ref_cells(_("#:"), 'order_number', '',null, '', true);

date_cells(_("from:"), 'OrdersAfterDate', '', null, -30);
date_cells(_("to:"), 'OrdersToDate');

locations_list_cells(_("into location:"), 'StockLocation', null, true);
end_row();
end_table();

start_table(TABLESTYLE_NOBORDER);
start_row();

stock_items_list_cells(_("for item:"), 'SelectStockFromList', null, true);

submit_cells('SearchOrders', _("Search"),'',_('Select documents'), 'default');
end_row();
end_table(1);
//---------------------------------------------------------------------------------------------
if (isset($_POST['order_number']))
{
	$order_number = $_POST['order_number'];
}

if (isset($_POST['SelectStockFromList']) &&	($_POST['SelectStockFromList'] != "") &&
	($_POST['SelectStockFromList'] != ALL_TEXT))
{
 	$selected_stock_item = $_POST['SelectStockFromList'];
}
else
{
	unset($selected_stock_item);
}

//---------------------------------------------------------------------------------------------
function trans_view($trans)
{
	return get_supplier_trans_view_str_consignment(ST_PURCHORDER, $trans["order_no"]);
}

function edit_link($row) 
{
	if (@$_GET['popup'])
		return '';
  	return pager_link( _("Edit"),
		"/purchasing/warranty_claim.php?" . SID
		. "ModifyOrderNumber=" . $row["order_no"], ICON_EDIT);
}

function prt_link($row)
{
	return print_document_link($row['order_no'], _("Print"), true, 18, ICON_PRINT);
}

//---------------------------------------------------------------------------------------------

$sql = get_warranty_claim();

$cols = array(
	_("#") => array('fun'=>'trans_view', 'ord'=>''),
	_("Supplier") => array('ord'=>''),
	_("Comments"),
	_("Order Date") => array('name'=>'ord_date', 'type'=>'date', 'ord'=>'desc'),
	_("Reference"),
	_("Stock Location"),
	_("Delivery Address"),
	_("Total"),
	_("Transaction Series"),
	_("Forward Date")=>array('name'=>'foward_date', 'type'=>'date', 'ord'=>'desc'),
	_("PR Type"),
	_("Material Center"),
	_("Import Number"),
	_("PO Date"),
	_("Delivery Terms"),
	_("Required For"),
	_("Shipment Mode"),
	_("GRN Reference"),
	_("Purchase ID"),
	_("PR No"),
	_("Tax Included"),
	_("Warranty Claim For File"),
	_("Acknowledgement#"),
	_("Supplier Invoice #"),
	_("GRN Transaction ID"),
	_("Repairing Reference"),
	_("Rectification Follow Up Advice"),
	_("Follow Up Rectification Advice"),
	_("Claim Status"),
	_("Fault Description"),
	_("Fault Rectification Advice"),
	_("Fault Rectification"),
	_("Claim Forward"),
	_("Supplier Invoice Date")=> array('name'=>'supplier_invoice_date', 'type'=>'date', 'ord'=>'desc'),

	array('insert'=>true, 'fun'=>'edit_link'),
		array('insert'=>true, 'fun'=>'prt_link'),
);

if (get_post('StockLocation') != $all_items) {
	$cols[_("Location")] = 'skip';
}
//---------------------------------------------------------------------------------------------------

$table =& new_db_pager('orders_tbl', $sql, $cols);

$table->width = "80%";

display_db_pager($table);

if (!@$_GET['popup'])
{
	end_form();
	end_page();
}	
?>
