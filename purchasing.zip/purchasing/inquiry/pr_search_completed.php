<?php
$page_security = 'SA_SUPPTRANSVIEW';
$path_to_root="../..";
include_once($path_to_root . "/includes/db_pager.inc");
include_once($path_to_root . "/includes/session.inc");

include_once($path_to_root . "/purchasing/includes/purchasing_ui.inc");
include_once($path_to_root . "/reporting/includes/reporting.inc");
if (!@$_GET['popup'])
{
	$js = "";
	if ($use_popup_windows)
		$js .= get_js_open_window(900, 500);
	if ($use_date_picker)
		$js .= get_js_date_picker();
	page(_($help_context = "Search Purchase Requisition "), false, false, "", $js);
}
if (isset($_GET['order_number']))
{
	$order_number = $_GET['order_number'];
}

//-----------------------------------------------------------------------------------
// Ajax updates
//
if (get_post('SearchOrders'))
{
	$Ajax->activate('orders_tbl');
} elseif (get_post('_order_number_changed'))
{
	$disable = get_post('order_number') !== '';

	$Ajax->addDisable(true, 'OrdersAfterDate', $disable);
	$Ajax->addDisable(true, 'OrdersToDate', $disable);
	$Ajax->addDisable(true, 'StockLocation', $disable);
	$Ajax->addDisable(true, '_SelectStockFromList_edit', $disable);
	$Ajax->addDisable(true, 'SelectStockFromList', $disable);

	if ($disable) {
		$Ajax->addFocus(true, 'order_number');
	} else
		$Ajax->addFocus(true, 'OrdersAfterDate');

	$Ajax->activate('orders_tbl');
}
//---------------------------------------------------------------------------------------------

if (!@$_GET['popup'])
	start_form();

start_table(TABLESTYLE_NOBORDER);
start_row();
date_cells(_("from:"), 'OrdersAfterDate', '', null, -30);
date_cells(_("to:"), 'OrdersToDate');
transaction_series_list_cells("Transaction Series", 'transaction_series', $_POST['transaction_series']);
Transaction_type_list_cells(_("Transaction Type:"),'transaction_type', null);
supplier_list_cells(_("Supplier:"), 'supplier_id', null, true, false, false, true);
custom_gst_type_list_cells1(_("PR Type"), 'select_pr', null, '', '', false, false);

import_number_list_cells(_("Import number:"), 'import_num', null);

//ref_cells(_("Import Number:"), 'Import_Number', '',null, '', true);
delivery_terms_list_cells(_("Delivery Terms:"), 'delivery_terms', null);
ref_cells(_("Required For:"), 'Required_For', '',null, '', true);
shipmentmode_list_cells(_("Shipment Mode:"), 'shipment_mode', null);
end_row();
start_row();
submit_cells('SearchOrders', _("Search"), '',_('Select documents'), 'default');
end_row();

end_table(1);
//---------------------------------------------------------------------------------------------
if (isset($_POST['order_number']))
{
	$order_number = $_POST['order_number'];
}

if (isset($_POST['SelectStockFromList']) &&	($_POST['SelectStockFromList'] != "") &&
	($_POST['SelectStockFromList'] != ALL_TEXT))
{
	$selected_stock_item = $_POST['SelectStockFromList'];
}
else
{
	unset($selected_stock_item);
}

//---------------------------------------------------------------------------------------------
function trans_view($trans)
{
	return get_trans_view_str(ST_PURCHASEREQUISITION, $trans["order_no"]);
}



function systype_name($dummy, $type)
{
    global $systypes_array;
    return $systypes_array[$type];
}
function get_delivery_terms_name_for_dashboard($id)
{
    $sql = "SELECT terms 
 			FROM ".TB_PREF."delivery_terms 
 			WHERE terms_indicator = ".db_escape($id['delivery_terms']);
    $db = db_query($sql, "Error");
    $ft = db_fetch($db);
    return $ft[0];
}
function get_shipment_mode_name_for_dashboard($id)
{
    $sql = "SELECT name 
 			FROM ".TB_PREF."shipmentmode 
 			WHERE id = ".db_escape($id['shipment_mode']);
    $db = db_query($sql, "Error");
    $ft = db_fetch($db);
    return $ft[0];
}

function edit_link($row)
{

	$result = check_pr_for_batch($row['order_no']);
	$result1 = check_pr_exist($row['order_no']);

	if($result)
	{
		return null;
	}
	else if($result1)
	{
		return null;

	}
	else {
		if (@$_GET['popup'])
			return '';
		return pager_link(_("Edit"),
			"/purchasing/purchasereq.php?" . SID
			. "ModifyOrderNumber=" . $row["order_no"], ICON_EDIT);
	}


//
//	$po=get_po_no_from_batch($row['order_no']);
//
//	$pr_qty=get_pr_quantity($row['order_no']);
//
//		echo "($pr_qty)";
//
//
//	$result=get_po_quantity($row['order_no']);
//
//	while($po_qty=db_fetch($result)){
//
//		echo $po_qty['quantity_ordered']."<br>";
//
//	}
}
function prt_link($row)
{
	return print_document_link($row['order_no'], _("Print"), true, ST_PURCHASEREQUISITION, ICON_PRINT);
}

if (isset($_POST['BatchInvoice']))
{
	// checking batch integrity
	$del_count = 0;
//var_dump($_POST['Sel_']);
//var_dump($_POST['mat_']);
	foreach($_POST['Sel_'] as $delivery => $branch) {
		$checkbox = 'Sel_'.$delivery;

		if(check_value($checkbox))	{

			if(!$del_count) {

				$del_branch = $branch;

			}
			else {
				if ($del_branch != $branch)	{
					$del_count=0;
					break;
				}
			}
			$selected[] = $delivery;
			$del_count++;
		}
	}

    $del_count1 = 0;

	foreach($_POST['mat_'] as $delivery1 => $branch1) {
		$checkbox1 = 'Sel_'.$delivery1;

		if(check_value($checkbox1))	{

			if(!$del_count1) {

				$del_branch1 = $branch1;

			}
			else {
				if ($del_branch1 != $branch1)	{
					$del_count1=0;
					break;
				}
			}
			$selected1[] = $delivery1;
			$del_count1++;
		}
	}

//	display_error($del_count1."+++++".$del_count);
//    die;




	if ($del_count1 == 0 || $del_count == 0) {
		display_error(_('For batch invoicing you should select at least one delivery. All items must be dispatched to the same Supplier.'));
	} else {
		$_SESSION['DeliveryBatch'] = $selected;
		meta_forward($path_to_root . '/purchasing/po_entry_items.php','BatchOrder=Yes&Type_Batch='.ST_BATCH);
	}
}




//if (isset($_POST['BatchInvoice']))
//{
//	// checking batch integrity
//	$del_count = 0;
////var_dump($_POST['Sel_']);
////var_dump($_POST['mat_']);
//	foreach($_POST['Sel_'] as $delivery => $branch) {
//		$checkbox = 'Sel_'.$delivery;
//
//		if(check_value($checkbox))	{
//
//			if(!$del_count) {
//
//				$del_branch = $branch;
//
//			}
//			else {
//				if ($del_branch != $branch)	{
//					$del_count=0;
//					break;
//				}
//			}
//			$selected[] = $delivery;
//			$del_count++;
//		}
//	}
//
//    $del_count1 = 0;
//
//	foreach($_POST['mat_'] as $delivery1 => $branch1) {
//		$checkbox1 = 'mat_'.$delivery1;
//
//		if(check_value($checkbox1))	{
//
//			if(!$del_count1) {
//
//				$del_branch1 = $branch1;
//
//			}
//			else {
//				if ($del_branch1 != $branch1)	{
//					$del_count1=0;
//					break;
//				}
//			}
//			$selected1[] = $delivery1;
//			$del_count1++;
//		}
//	}
//
////	display_error($del_count1."+++++".$del_count);
////    die;
//
//	if (!$del_count1 && !$del_count) {
//		display_error(_('For batch invoicing you should select at least one delivery. All items must be dispatched to the same Supplier.'));
//	} else {
//		$_SESSION['DeliveryBatch'] = $selected;
//		meta_forward($path_to_root . '/purchasing/po_entry_items.php','BatchOrder=Yes&Type_Batch='.ST_BATCH);
//	}
//}

function get_import_number_names($row)
{
    $sql = "SELECT name FROM ".TB_PREF."import_number
     WHERE id=".db_escape($row['import_num']);

    $result = db_query($sql,"could not get IMPORT NUMBER");
    $row = db_fetch_row($result);
    return $row[0];
}
function batch_checkbox($row)
{
	$result = check_pr_for_batch($row['order_no']);
	$result1 = check_pr_exist($row['order_no']);
	if($result > 0)
	{
		return null;
	}
	elseif ($result1 > 0)
	{
		return null;
	}
	else
	{
		$name = "Sel_" . $row['order_no'];
//		$name1 = "mat_" . $row['order_no'];
//        <input type='checkbox' name='$name1' value='1' >
		return $row['Done'] ? '' :
			"<input type='checkbox' name='$name' value='1' >"
// add also trans_no => branch code for checking after 'Batch' submit
			. "<input name='Sel_[" . $row['order_no'] . "]' type='hidden' value='"
			. $row['supplier_id']."'>
			<input name='mat_[" . $row['order_no'] . "]' type='hidden' value='"
			. $row['material_centre']."'>\n";
	}
}

function po_link($row)
{
	return pager_link( _("Receive"),
		"/purchasing/po_entry_items.php?Type_req=" .ST_PURCHASEREQUISITION ."&". "AddRequisition=" . $row["order_no"], ICON_RECEIVE);
}
//---------------------------------------------------------------------------------------------
$sql = get_sql_for_pr_search_completed($_POST['transaction_series'], $_POST['transaction_type'],
    $_POST['supplier_id'], $_POST['select_pr'], $_POST['Import_Number'],
    $_POST['delivery_terms'], $_POST['Required_For'], $_POST['shipment_mode']);

$cols = array(
	_("#") => array('fun'=>'trans_view', 'ord'=>'desc'),
	_("Transaction Series")=> array('fun'=>'get_transaction_series_name'),
    _("Transaction Type")=> array('fun'=>'get_transaction_type_name'),
    _("Voucher Date") => array('name'=>'pr_date', 'type'=>'date', 'ord'=>''),
	_("Supplier") => array('ord'=>''),
	_("PR Type") => array('fun'=>'systype_name'),
	_("Import Number")=> array('fun'=>'get_import_number_names'),
	_("PR Date") => array('name'=>'pr_date', 'type'=>'date', 'ord'=>''),
	_("Delivery Terms") => array('align'=>'center', 'fun' => 'get_delivery_terms_name_for_dashboard'),
	_("Required For") => array('align'=>'center'),
	_("Shipment Mode") => array('align'=>'center', 'fun' => 'get_shipment_mode_name_for_dashboard'),
	_("Order Total") => 'amount',
	_("Material Centre"),
	submit('BatchInvoice',_("Batch"), false, _("Batch Invoicing"))
	=> array('insert'=>true, 'fun'=>'batch_checkbox', 'align'=>'center'),
	array('insert'=>true, 'fun'=>'edit_link'),
	"PO" =>array('insert'=>true, 'fun'=>'po_link'),
	array('insert'=>true, 'fun'=>'prt_link'));
if(get_post('StockLocation') != $all_items)
{$cols[_("Location")] = 'skip';}
//---------------------------------------------------------------------------------------------------
if (isset($_SESSION['Batch']))
{
	foreach($_SESSION['Batch'] as $trans=> $del)
		unset($_SESSION['Batch'][$trans]);
	unset($_SESSION['Batch']);
}

$table =& new_db_pager('orders_tbl', $sql, $cols);

$table->width = "80%";

display_db_pager($table);

if (!@$_GET['popup'])
{
	end_form();
	end_page();
}
?>