<?php
$page_security = 'SA_SUPPTRANSVIEW';
$path_to_root = "../..";
include($path_to_root . "/includes/db_pager.inc");
include($path_to_root . "/includes/session.inc");

include($path_to_root . "/purchasing/includes/purchasing_ui.inc");
include_once($path_to_root . "/reporting/includes/reporting.inc");

$js = "";
if ($use_popup_windows)
	$js .= get_js_open_window(900, 500);
if ($use_date_picker)
	$js .= get_js_date_picker();
page(_($help_context = "Search Warranty Claim"), false, false, "", $js);

if (isset($_GET['order_number']))
{
	$_POST['order_number'] = $_GET['order_number'];
}
//-----------------------------------------------------------------------------------
// Ajax updates
//
/*if (get_post('SearchOrders'))
{
	$Ajax->activate('orders_tbl');
} elseif (get_post('_order_number_changed')) 
{
	$disable = get_post('order_number') !== '';

	$Ajax->addDisable(true, 'OrdersAfterDate', $disable);
		$Ajax->addDisable(true, 'OrdersToDate', $disable);
	$Ajax->addDisable(true, 'StockLocation', $disable);
	$Ajax->addDisable(true, '_SelectStockFromList_edit', $disable);
	$Ajax->addDisable(true, 'SelectStockFromList', $disable);

	if ($disable) {
		$Ajax->addFocus(true, 'order_number');
	} else
		$Ajax->addFocus(true, 'OrdersAfterDate');

	$Ajax->activate('orders_tbl');
}*/

///-----------------------------------------------------------
//get Roles against each alert for email
function get_role_against_alert_id($alert_id)
{
	$sql= "SELECT u.email
			FROM 0_users u  , 0_roles_for_system_alerts r
			WHERE u.role_id = r.role_id
			AND r.system_alert_id = '$alert_id'";

	return db_query($sql,'Could not get user email');
//	$ft = db_fetch($db);
//	return $ft;
}

//---------------------------------------------------------------------------------------------
//alerts function
function get_alerts($alert_id)
{
	$sql= "SELECT * FROM ".TB_PREF."systems_alerts where alert_id=".db_escape($alert_id)."";
	$db = db_query($sql,'Could not get System Alerts');
	$ft = db_fetch($db);
	return $ft;
}

function get_alerts_for_PO($valid_days)
{
	$today= date('d-m-Y');
//	display_error($today);
//	display_error($valid_days.'asdas');
	$dt = date('Y-m-d', strtotime($today. ' - '.$valid_days.' days'));

	/*$sql= "SELECT PR.* FROM ".TB_PREF."purch_requisition PR , ".TB_PREF."purch_orders PO
			where PR.order_no != PO.pr_no AND PR.pr_date <= '$dt' 
			GROUP BY PR.order_no";*/

	$sql="SELECT  PR.* FROM ".TB_PREF."purch_requisition PR
			LEFT JOIN 
			".TB_PREF."purch_orders PO ON 
			PR.order_no = PO.pr_no 
			WHERE 		
			 ISNULL(PO.pr_no)
			AND PR.pr_date <= '$dt'
			";

	return db_query($sql,'Could not get System Alerts');
}

//-----------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------- Alert 1-------------------------------------------------
//-----------------------------------------------------------------------------------------------------------------------

// Alets variables

$alert_no_1 = get_alerts(1);

$po =  get_alerts_for_PO($alert_no_1['valid_days']);
//---------------------------------------------------------------------------------------------

start_form();

echo '
<div style="width:50%;background-color: #77a1ff;margin-top: 5px;">
	<span><center> Alert 1 </center> </span>
	<table width="100%">';
echo "<tr><td>Order NO</td><td> Required For </td><td>  Days over</td></tr>";
while($t_data = db_fetch($po)) {
	$dt2 = date('Y-m-d', strtotime($t_data['pr_date']. ' + '.$alert_no_1['valid_days'].' days'));
	$diff_days = date_diff2(Today(), sql2date($dt2), "d");
	echo "<tr><td>".$t_data['order_no']."</td><td> ".$t_data['requiredfor']." </td><td>  ".$diff_days."</td></tr>";
}
	echo'</table>
</div>
';
//-------------------------------------------------------------------------------------------------------------
//---------------------------------------------------- ALERT 2 ------------------------------------------------
//-------------------------------------------------------------------------------------------------------------
function get_alerts_for_delivery_update($valid_days)
{
	$today= date('d-m-Y');
	$valid_date = date('Y-m-d', strtotime($today. ' - '.$valid_days.' days'));
	$sql= "SELECT * FROM `0_purch_orders` WHERE `delivery_date`='0000-00-00' AND ord_date < ".db_escape($valid_date )."";
	return db_query($sql,'Could not get System Alerts 2 ');
}


$alert_no_2 = get_alerts(2);
$delivery_date_alert =  get_alerts_for_delivery_update($alert_no_2['valid_days']);


echo '
<div style="width:50%;background-color: #77a1ff;margin-top: 5px;">
	<span><center> Alert 2  </center> </span>
	<table width="100%">';
echo "<tr><td>Order NO</td><td> Supplier</td><td> Required For </td><td>  Days over</td></tr>";
while($t_data = db_fetch($delivery_date_alert))
{
	$dt2 = date('Y-m-d', strtotime($t_data['ord_date']. ' + '.$alert_no_2['valid_days'].' days'));
	$diff_days = date_diff2(Today(), sql2date($dt2), "d");
	echo "<tr><td>".$t_data['order_no']."</td><td> ".get_supplier_name($t_data['supplier_id'])." </td><td>  ".$t_data['requiredfor']."</td><td>  ".$diff_days."</td></tr>";
}
echo'</table>
</div>
';

//-------------------------------------------------------------------------------------------------------------
//---------------------------------------------------- ALERT 3 ------------------------------------------------
//-------------------------------------------------------------------------------------------------------------
function get_alerts_for_consigment_status($valid_days)
{
	$today= date('d-m-Y');
	$valid_date = date('Y-m-d', strtotime($today. ' - '.$valid_days.' days'));
/*	$sql= " SELECT PO . *
			FROM  `0_purch_orders` PO, 0_purch_orders1 Po1
			WHERE PO.order_no != Po1.po_no
			AND PO.acknowledge_status !=  '2' AND PO.ord_date < ".db_escape($valid_date)."  ";*/

	/*$sql="SELECT  PO.* FROM 0_purch_orders PO
			LEFT JOIN 
			0_purch_orders1 Po1 ON 
			PO.order_no = po1.po_no 
			WHERE 
			PO.status_type = '0'
			AND ISNULL(po1.po_no)
			AND PO.ord_date < $valid_date ";*/
	$sql =" SELECT po1.* FROM 0_purch_orders1 po1   
			WHERE po1.status_type = '0'
			AND po1.ord_date < '$valid_date' ";

	return db_query($sql,'Could not get System Alerts 2 ');
}


$alert_no_3 = get_alerts(3);
$consigment_status =  get_alerts_for_consigment_status($alert_no_3['valid_days']);

echo '
<div style="width:50%;background-color: #77a1ff;margin-top: 5px;">
	<span><center> Alert 3  </center> </span>
	<table width="100%">';
echo "<tr><td>Order NO</td><td> Supplier</td><td> Required For </td><td>  Days over</td></tr>";
while($t_data = db_fetch($consigment_status))
{
	$dt2 = date('Y-m-d', strtotime($t_data['ord_date']. ' + '.$alert_no_3['valid_days'].' days'));
	$diff_days = date_diff2(Today(), sql2date($dt2), "d");

//	display_error(Today());
//	display_error(sql2date($dt2));
//	display_error($diff_days);

	echo "<tr><td>".$t_data['order_no']."</td><td> ".get_supplier_name($t_data['supplier_id'])." </td><td>  ".$t_data['requiredfor']."</td><td>  ".$diff_days."</td></tr>";
}
echo'</table>
</div>
';

//-------------------------------------------------------------------------------------------------------------
//---------------------------------------------------- ALERT 4 ------------------------------------------------
//-------------------------------------------------------------------------------------------------------------
function get_alerts_for_consigment_delay($valid_days)
{
	$today= date('d-m-Y');
	$valid_date = date('Y-m-d', strtotime($today. ' - '.$valid_days.' days'));
		/*$sql= " SELECT * FROM `0_purch_orders1`
				WHERE  `arrival_date` < '$valid_date'";*/
		$sql="SELECT po1.* FROM 0_purch_orders1 po1 WHERE 
				po1.status_type != '4' 
				AND po1.arrival_date != '000-00-00'
				AND po1.arrival_date < '$valid_date' ";

	return db_query($sql,'Could not get System Alerts 4 ');
}


$alert_no_4 = get_alerts(4);
$consigment_delay =  get_alerts_for_consigment_delay($alert_no_4['valid_days']);


echo '
<div style="width:50%;background-color: #77a1ff;margin-top: 5px;">
	<span><center> Alert 4  </center> </span>
	<table width="100%">';
echo "<tr><td>Purchase Id</td><td>Supplier </td><td>Required for</td><td> Days over</td></tr>";
while($t_data = db_fetch($consigment_delay))
{
	$dt2 = date('Y-m-d', strtotime($t_data['ord_date']. ' + '.$alert_no_4['valid_days'].' days'));

	$diff_days = date_diff2(Today(), sql2date($dt2), "d");
	echo "<tr><td>".$t_data['order_no']."</td><td> ".get_supplier_name($t_data['supplier_id'])." </td><td> ".$t_data['requiredfor']." </td><td>  ".$diff_days."</td></tr>";
}
echo'</table>
</div>
';

//-------------------------------------------------------------------------------------------------------------
//---------------------------------------------------- ALERT 5 ------------------------------------------------
//-------------------------------------------------------------------------------------------------------------
function get_alerts_for_consigment_ready_date($valid_days)
{
	$today= date('d-m-Y');
	$valid_date = date('Y-m-d', strtotime($today. ' - '.$valid_days.' days'));
	$sql= "SELECT * FROM `0_purch_orders1` 
			WHERE  `ready_date` != '0000-00-00' ";

	return db_query($sql,'Could not get System Alerts 2 ');
}


$alert_no_5 = get_alerts(5);
$consigment_ready_date =  get_alerts_for_consigment_ready_date($alert_no_5['valid_days']);


echo '
<div style="width:50%;background-color: #77a1ff;margin-top: 5px;">
	<span><center>Alert 5  </center> </span>
	<table width="100%">';
echo "<tr><td>Order NO</td><td> Supplier</td><td> Ready Date </td><td> Required For </td><td>Shiipment Mode</td></tr>";
while($t_data = db_fetch($consigment_ready_date))
{
	$dt2 = date('Y-m-d', strtotime($t_data['ord_date']. ' + '.$alert_no_5['valid_days'].' days'));
	$diff_days = date_diff2(Today(), sql2date($dt2), "d");
	echo "<tr><td>".$t_data['order_no']."</td><td> ".get_supplier_name($t_data['supplier_id'])." </td><td> ".sql2date($t_data['ready_date'])." </td><td>  ".$t_data['requiredfor']."</td><td>  ". get_shipment_name($t_data['shipment_mode'])."</td></tr>";
}
echo'</table>
</div>
';



//-------------------------------------------------------------------------------------------------------------
//---------------------------------------------------- ALERT 6 ------------------------------------------------
//-------------------------------------------------------------------------------------------------------------
function get_alerts_for_consigment_arrived_at_office($valid_days)
{
	$today= date('d-m-Y');
	$valid_date = date('Y-m-d', strtotime($today. ' - '.$valid_days.' days'));
	$sql= "SELECT * FROM `0_purch_orders1` 
			WHERE  status_type = '4'";

	return db_query($sql,'Could not get System Alerts 2 ');
}


$alert_no_6 = get_alerts(6);
$consigment_ready_date =  get_alerts_for_consigment_arrived_at_office($alert_no_6['valid_days']);


echo '
<div style="width:50%;background-color: #77a1ff;margin-top: 5px;">
	<span><center> Alert 6  </center> </span>
	<table width="100%">';
echo "<tr><td>Order NO</td><td> Supplier</td><td>Required For</td></tr>";
while($t_data = db_fetch($consigment_ready_date))
{
//	$dt2 = date('Y-m-d', strtotime($t_data['ord_date']. ' + '.$alert_no_6['valid_days'].' days'));
//	$diff_days = date_diff2(Today(), sql2date($dt2), "d");
	echo "<tr><td>".$t_data['order_no']."</td><td> ".get_supplier_name($t_data['supplier_id'])." </td><td>  ".$t_data['requiredfor']."</td></tr>";
}
echo'</table>
</div>
';

//-------------------------------------------------------------------------------------------------------------
//---------------------------------------------------- ALERT 7 ------------------------------------------------
//-------------------------------------------------------------------------------------------------------------
function get_alerts_for_weight_and_dimension_not_fed($valid_days)
{
	$today= date('d-m-Y');
	$valid_date = date('Y-m-d', strtotime($today. ' - '.$valid_days.' days'));
	$sql= "SELECT * FROM `0_purch_orders1` 
			WHERE  ready_date < '$valid_date' AND weight_dimension='' ";
	return db_query($sql,'Could not get System Alerts 2 ');
}


$alert_no_7 = get_alerts(7);
$weight_and_dimension_not_fed =  get_alerts_for_weight_and_dimension_not_fed($alert_no_7['valid_days']);


echo '
<div style="width:50%;background-color: #77a1ff;margin-top: 5px;">
	<span><center> Alert 7  </center> </span>
	<table width="100%">';
echo "<tr><td>Order NO</td><td> Supplier</td><td> Required For </td><td>Days Over</td></tr>";
while($t_data = db_fetch($weight_and_dimension_not_fed))
{
	$dt2 = date('Y-m-d', strtotime($t_data['ready_date']. ' + '.$alert_no_7['valid_days'].' days'));
	$diff_days = date_diff2(Today(), sql2date($dt2), "d");
	echo "<tr><td>".$t_data['order_no']."</td><td> ".get_supplier_name($t_data['supplier_id'])." </td><td> ".$t_data['requiredfor']." </td><td>  ". $diff_days."</td></tr>";
}
echo'</table>
</div>
';

//-------------------------------------------------------------------------------------------------------------
//---------------------------------------------------- ALERT 8 ------------------------------------------------
//-------------------------------------------------------------------------------------------------------------
function get_alerts_for_grn($valid_days)
{
	$today= date('d-m-Y');
	$valid_date = date('Y-m-d', strtotime($today. ' - '.$valid_days.' days'));
	$sql= "SELECT po1.* FROM 0_purch_orders po
			LEFT JOIN  0_purch_orders1 po1  ON 
			po.order_no = po1.po_no 
			LEFT JOIN 0_grn_batch grn on
			grn.purch_order_no = po.order_no
			WHERE po.order_no = po1.po_no  
			AND po1.arrival_date < '$valid_date'
			AND  ISNULL(grn.purch_order_no)";

	return db_query($sql,'Could not get System Alerts 2 ');
}

$alert_no_8 = get_alerts(8);
$grn_alert =  get_alerts_for_grn($alert_no_8['valid_days']);

echo '
<div style="width:50%;background-color: #77a1ff;margin-top: 5px;">
	<span><center> Alert 8  </center> </span>
	<table width="100%">';
echo "<tr><td>Order NO</td><td> Supplier</td><td> Required For </td><td> Arrival Date</td><td>Days Over</td></tr>";
while($t_data = db_fetch($grn_alert))
{
	$dt2 = date('Y-m-d', strtotime($t_data['ord_date']. ' + '.$alert_no_8['valid_days'].' days'));
	$diff_days = date_diff2(Today(), sql2date($dt2), "d");
	echo "<tr><td>".$t_data['order_no']."</td><td> ".get_supplier_name($t_data['supplier_id'])." </td><td> ".$t_data['requiredfor']." </td><td> ".sql2date($t_data['arrival_date'])." </td><td>  ". $diff_days."</td></tr>";
}
echo'</table>
</div>
';

//-------------------------------------------------------------------------------------------------------------
//---------------------------------------------------- ALERT 11 ------------------------------------------------
//-------------------------------------------------------------------------------------------------------------
function get_alerts_for_short_item_recieved_intimation()
{
//	$today= date('d-m-Y');
//	$valid_date = date('Y-m-d', strtotime($today. ' - '.$valid_days.' days'));
	$sql= "SELECT csm.*, grn.quantity_inv ,grn_batach.supplier_id , grn_batach.required_for

			FROM `0_claim_for_short_material_details` csm , 0_grn_items grn , 0_grn_batch grn_batach
			WHERE csm.`po_detail_item` = grn.`po_detail_item`
			AND grn_batach.id = grn.grn_batch_id
			GROUP BY csm.`po_detail_item`";

	return db_query($sql,'Could not get System Alerts 11 ');
}

//$alert_no_11 = get_alerts(11);
$grn_alert =  get_alerts_for_short_item_recieved_intimation();

echo '
<div style="width:50%;background-color: #77a1ff;margin-top: 5px;">
	<span><center> Alert 11  </center> </span>
	<table width="100%">';
echo "<tr><td>Order NO</td><td> Supplier</td><td> Required For </td><td>Item Title</td><td>Recieved Qty in GRN</td><td>Qty at Credit Bill</td></tr>";
while($t_data = db_fetch($grn_alert))
{
	$dt2 = date('Y-m-d', strtotime($t_data['ord_date']. ' + '.$alert_no_11['valid_days'].' days'));
	$diff_days = date_diff2(Today(), sql2date($dt2), "d");
	echo "<tr><td>".$t_data['order_no']."</td><td> ".get_supplier_name($t_data['supplier_id'])." </td><td> ".$t_data['required_for']." </td><td> ".$t_data['description']." </td><td>". $t_data['quantity_received']."</td><td>". $t_data['quantity_inv']."</td></tr>";
}
echo'</table>
</div>
';


//-------------------------------------------------------------------------------------------------------------
//---------------------------------------------------- ALERT 12 ------------------------------------------------
//-------------------------------------------------------------------------------------------------------------
function get_alerts_for_equipmentfor_repairing_not_send_to_supplier($valid_days)
{
	$today= date('d-m-Y');
	$valid_date = date('Y-m-d', strtotime($today. ' - '.$valid_days.' days'));
	$sql= "SELECT head.order_no , head.supplier_id , head.supp_ref , head.requiredfor,head.gts_dispatch_date
			FROM 0_repairing_through_supplier head, 0_repairing_through_supplier_details child
			WHERE head.dispatch_to_supplier ='1' AND head.supp_ref != '' 
			AND head.gts_dispatch_date < '$valid_date'";

	return db_query($sql,'Could not get System Alerts 11 ');
}

$alert_no_12 = get_alerts(12);
$equipmentfor_repairing_not_send_to_supplier =  get_alerts_for_equipmentfor_repairing_not_send_to_supplier($alert_no_12['valid_days']);

echo '
<div style="width:50%;background-color: #77a1ff;margin-top: 5px;">
	<span><center> Alert 12  </center> </span>
	<table width="100%">';
echo "<tr><td>Order No</td><td>Supplier</td><td>Supplier Repair Ref </td><td>Days Over</td></tr>";
while($t_data = db_fetch($equipmentfor_repairing_not_send_to_supplier))
{
	$dt2 = date('Y-m-d', strtotime($t_data['gts_dispatch_date']. ' + '.$alert_no_12['valid_days'].' days'));
	$diff_days = date_diff2(Today(), sql2date($dt2), "d");
	echo "<tr><td>".$t_data['order_no']."</td><td> ".get_supplier_name($t_data['supplier_id'])." </td><td> ".$t_data['supp_ref']." </td><td>". $diff_days."</td></tr>";
}
echo'</table>
</div>
';

//-------------------------------------------------------------------------------------------------------------
//---------------------------------------------------- ALERT 14 ------------------------------------------------
//-------------------------------------------------------------------------------------------------------------
function get_alerts_for_warranty_app_status($valid_days)
{
	$today= date('d-m-Y');
	$valid_date = date('Y-m-d', strtotime($today. ' - '.$valid_days.' days'));
	$sql= "SELECT wc.* ,wcd.description
			FROM `0_warranty_claim` wc , 0_warranty_claim_details wcd
			WHERE warranty_approoval_status ='3'
			AND wc.order_no = wcd.order_no
			AND wc.po_date < '$valid_date'";

	return db_query($sql,'Could not get System Alerts 14 ');
}

$alert_no_14 = get_alerts(14);
$get_alerts_for_warranty_app_status =  get_alerts_for_warranty_app_status($alert_no_14['valid_days']);

echo '
<div style="width:50%;background-color: #77a1ff;margin-top: 5px;">
	<span><center>Alert 14 </center> </span>
	<table width="100%">';
echo "<tr><td>Transaction ID</td><td>Item Title</td><td>Customer Name</td><td>Days Over</td></tr>";
while($t_data = db_fetch($get_alerts_for_warranty_app_status))
{

	$dt2 = date('Y-m-d', strtotime($t_data['po_date']. ' + '.$alert_no_14['valid_days'].' days'));
	$diff_days = date_diff2(Today(), sql2date($dt2), "d");
	echo "<tr><td>".$t_data['order_no']."</td><td> ".$t_data['description']." </td><td> ".$t_data['requiredfor']." </td><td>". $diff_days."</td></tr>";
}
echo'</table>
</div>
';
//-------------------------------------------------------------------------------------------------------------
//---------------------------------------------------- ALERT 16 ------------------------------------------------
//-------------------------------------------------------------------------------------------------------------
function get_alerts_for_supp_inv_not_fed($valid_days)
{
	$today= date('d-m-Y');
	$valid_date = date('Y-m-d', strtotime($today. ' - '.$valid_days.' days'));
	$sql= " SELECT grn.* FROM 0_grn_batch grn 
			LEFT JOIN 0_supp_invoice_items supp ON 
			grn.grn_no = supp.grn_item_id  
			WHERE 
			grn.supp_invoice_date < '$valid_date'
			AND ISNULL(supp.grn_item_id)";

	return db_query($sql,'Could not get System Alerts 14 ');
}

$alert_no_16 = get_alerts(16);
$get_alerts_for_supp_inv_not_fed =  get_alerts_for_supp_inv_not_fed($alert_no_16['valid_days']);

echo '
<div style="width:50%;background-color: #77a1ff;margin-top: 5px;">
	<span><center>Top 5 Alert 16 </center> </span>
	<table width="100%">';
echo "<tr><td>Order no</td><td>GRN feedind Date</td><td>Days Over</td></tr>";
while($t_data = db_fetch($get_alerts_for_supp_inv_not_fed))
{

	$dt2 = date('Y-m-d', strtotime($t_data['supp_invoice_date']. ' + '.$alert_no_16['valid_days'].' days'));
	$diff_days = date_diff2(Today(), sql2date($dt2), "d");
	echo "<tr><td>".$t_data['id']."</td><td> ".sql2date($t_data['supp_invoice_date'])." </td><td>". $diff_days."</td></tr>";
}
echo'</table>
</div>
';


end_form();
end_page();
?>
