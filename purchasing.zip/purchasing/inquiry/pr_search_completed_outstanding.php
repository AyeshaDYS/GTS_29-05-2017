<?php
$page_security = 'SA_SUPPTRANSVIEW';
$path_to_root="../..";
include_once($path_to_root . "/includes/db_pager.inc");
include_once($path_to_root . "/includes/session.inc");

include_once($path_to_root . "/purchasing/includes/purchasing_ui.inc");
include_once($path_to_root . "/reporting/includes/reporting.inc");
if (!@$_GET['popup'])
{
	$js = "";
	if ($use_popup_windows)
		$js .= get_js_open_window(900, 500);
	if ($use_date_picker)
		$js .= get_js_date_picker();
	page(_($help_context = "Search Purchase Requisition "), false, false, "", $js);
}
//if (isset($_GET['order_number']))
//{
//	$order_number = $_GET['order_number'];
//}

//-----------------------------------------------------------------------------------
// Ajax updates
//
if (get_post('SearchOrders'))
{
	$Ajax->activate('orders_tbl');
} elseif (get_post('_order_number_changed'))
{
	$disable = get_post('order_number') !== '';

	$Ajax->addDisable(true, 'OrdersAfterDate', $disable);
	$Ajax->addDisable(true, 'OrdersToDate', $disable);
	$Ajax->addDisable(true, 'StockLocation', $disable);
	$Ajax->addDisable(true, '_SelectStockFromList_edit', $disable);
	$Ajax->addDisable(true, 'SelectStockFromList', $disable);

	if ($disable) {
		$Ajax->addFocus(true, 'order_number');
	} else
		$Ajax->addFocus(true, 'OrdersAfterDate');

	$Ajax->activate('orders_tbl');
}
//---------------------------------------------------------------------------------------------

if (!@$_GET['popup'])
	start_form();

start_table(TABLESTYLE_NOBORDER);
start_row();
ref_cells(_("#:"), 'order_number', '',null, '', true);

date_cells(_("from:"), 'OrdersAfterDate', '', null, -30);
date_cells(_("to:"), 'OrdersToDate');

locations_list_cells(_("into location:"), 'StockLocation', null, true);
end_row();
end_table();

start_table(TABLESTYLE_NOBORDER);
start_row();

stock_items_list_cells(_("for item:"), 'SelectStockFromList', null, true);

submit_cells('SearchOrders', _("Search"),'',_('Select documents'), 'default');
end_row();

end_table(1);
//---------------------------------------------------------------------------------------------
if (isset($_POST['order_number']))
{
	$order_number = $_POST['order_number'];
}

if (isset($_POST['SelectStockFromList']) &&	($_POST['SelectStockFromList'] != "") &&
	($_POST['SelectStockFromList'] != ALL_TEXT))
{
	$selected_stock_item = $_POST['SelectStockFromList'];
}
else
{
	unset($selected_stock_item);
}

//---------------------------------------------------------------------------------------------
function trans_view($trans)
{
	return get_trans_view_str(ST_PURCHASEREQUISITION, $trans["order_no"]);
}

//function edit_link($row)
//{
//	if (@$_GET['popup'])
//		return '';
//	return pager_link( _("Edit"),
//		"/purchasing/po_entry_items1.php?" . SID
//		. "ModifyOrderNumber=" . $row["order_no"], ICON_EDIT);
//}


function edit_link($row)
{

$result=check_pr_for_batch($row['order_no']);
//
//	$po=get_po_no_from_batch($row['order_no']);
//
//	$pr_qty=get_pr_quantity($row['order_no']);
//
//		echo "($pr_qty)";
//
//
//	$result=get_po_quantity($row['order_no']);
//
//	while($po_qty=db_fetch($result)){
//
//		echo $po_qty['quantity_ordered']."<br>";
//
//	}






if($result)
{
	return null;
}
else {
	if (@$_GET['popup'])
		return '';
	return pager_link(_("Edit"),
		"/purchasing/purchasereq.php?" . SID
		. "ModifyOrderNumber=" . $row["order_no"], ICON_EDIT);
}
}

function prt_link($row)
{
	return print_document_link($row['order_no'], _("Print"), true, 18, ICON_PRINT);
}

if (isset($_POST['BatchInvoice']))
{
	// checking batch integrity
	$del_count = 0;
	foreach($_POST['Sel_'] as $delivery => $branch) {
		$checkbox = 'Sel_'.$delivery;

		if(check_value($checkbox))	{

			if(!$del_count) {

				$del_branch = $branch;

			}
			else {
				if ($del_branch != $branch)	{
					$del_count=0;
					break;
				}
			}
			$selected[] = $delivery;
			$del_count++;
		}
	}

	if (!$del_count) {
		display_error(_('For batch invoicing you should select at least one delivery. All items must be dispatched to the same Supplier.'));
	} else {
		$_SESSION['DeliveryBatch'] = $selected;
		meta_forward($path_to_root . '/purchasing/po_entry_items.php','BatchOrder=Yes');
	}
}

function batch_checkbox($row)
{$result=check_pr_for_batch($row['order_no']);

	if($result>0)
	{
		return null;
	}
	else
	{
		
		$name = "Sel_" . $row['order_no'];

		return $row['Done'] ? '' :
			"<input type='checkbox' name='$name' value='1' >"
// add also trans_no => branch code for checking after 'Batch' submit
			. "<input name='Sel_[" . $row['order_no'] . "]' type='hidden' value='"
			. $row['supplier_id'] . "'>\n";
	}
}

function po_link($row)
{
	return pager_link( _("Receive"),
		"/purchasing/po_entry_items.php?Type_req=" .ST_PURCHASEREQUISITION ."&". "AddRequisition=" . $row["order_no"], ICON_RECEIVE);
}

//---------------------------------------------------------------------------------------------


if($result)
{
	//echo $result ;

}

$sql = get_sql_for_pr_search_completed_outstanding();

$cols = array(
	_("#") => array('fun'=>'trans_view', 'ord'=>'asc'),
	_("Reference"),
	_("Supplier") => array('ord'=>''),
	_("Location"),
	//_("Supplier's Reference"),
	_("PR Date") => array('name'=>'ord_date', 'type'=>'date', 'ord'=>''),
	_("Currency") => array('align'=>'center'),
	_("Order Total") => 'amount',
	submit('BatchInvoice',_("Batch"), false, _("Batch Invoicing"))
	=> array('insert'=>true, 'fun'=>'batch_checkbox', 'align'=>'center'),
	array('insert'=>true, 'fun'=>'edit_link'),
	_("PO") =>array('insert'=>true, 'fun'=>'po_link'),
	array('insert'=>true, 'fun'=>'prt_link')

);
if (get_post('StockLocation') != $all_items) {
	$cols[_("Location")] = 'skip';
}
//---------------------------------------------------------------------------------------------------
if (isset($_SESSION['Batch']))
{
	foreach($_SESSION['Batch'] as $trans=> $del)
		unset($_SESSION['Batch'][$trans]);
	unset($_SESSION['Batch']);
}



$table =& new_db_pager('orders_tbl', $sql, $cols);

$table->width = "80%";

display_db_pager($table);

if (!@$_GET['popup'])
{
	end_form();
	end_page();
}
?>
