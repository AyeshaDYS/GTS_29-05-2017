<?php
$page_security = 'SA_SUPPTRANSVIEW';
$path_to_root="../..";
include_once($path_to_root . "/includes/db_pager.inc");
include_once($path_to_root . "/includes/session.inc");

include_once($path_to_root . "/purchasing/includes/purchasing_ui.inc");
include_once($path_to_root . "/reporting/includes/reporting.inc");
if (!@$_GET['popup'])
{
	$js = "";
	if ($use_popup_windows)
		$js .= get_js_open_window(900, 500);
	if ($use_date_picker)
		$js .= get_js_date_picker();
	page(_($help_context = "Search Repairing through supplier"), false, false, "", $js);
}
if (isset($_GET['order_number']))
{
	$order_number = $_GET['order_number'];
}

//-----------------------------------------------------------------------------------
// Ajax updates
//
if (get_post('SearchOrders'))
{
	$Ajax->activate('orders_tbl');
} elseif (get_post('_order_number_changed'))
{
	$disable = get_post('order_number') !== '';

	$Ajax->addDisable(true, 'OrdersAfterDate', $disable);
	$Ajax->addDisable(true, 'OrdersToDate', $disable);
	$Ajax->addDisable(true, 'StockLocation', $disable);
	$Ajax->addDisable(true, '_SelectStockFromList_edit', $disable);
	$Ajax->addDisable(true, 'SelectStockFromList', $disable);

	if ($disable) {
		$Ajax->addFocus(true, 'order_number');
	} else
		$Ajax->addFocus(true, 'OrdersAfterDate');

	$Ajax->activate('orders_tbl');
}
//---------------------------------------------------------------------------------------------

if (!@$_GET['popup'])
	start_form();

start_table(TABLESTYLE_NOBORDER);
start_row();
//ref_cells(_("#:"), 'order_number', '',null, '', true);

date_cells(_("from:"), 'OrdersAfterDate', '', null, -30);
date_cells(_("to:"), 'OrdersToDate');
transaction_series_list_cells("Transaction Series", 'transaction_series', null);
dispatch_supplier_list_cells(_("Dispatch to Supplier:"), 'dispatch_to_supplier', null);
ref_cells(_("Supplier Repairing Reference:"), 'Supplier_Repairing_Reference', '',null, '', true);
ref_cells(_("Repairing Transaction ID:"), 'Repairing_Transaction_ID', '',null, '', true);
ref_cells(_("GRN Transaction ID:"), 'GRN_Transaction_ID', '',null, '', true);
ref_cells(_("Dispatch Status:"), 'Dispatch_Status', '',null, '', true);
ref_cells(_("Voucher:"), 'Voucher', '',null, '', true);
ref_cells(_("Inspection report/DCN"), 'Inspection_report_DCN', '',null, '', true);
ref_cells(_("Our Service order to Supplier"), 'Our_Service_order_to_Supplier', '',null, '', true);
ref_cells(_("GTS Dispatch VIA"), 'GTS_Dispatch_VIA', '',null, '', true);
ref_cells(_("GTS Dispatch Tracking "), 'GTS_Dispatch_Tracking', '',null, '', true);
ref_cells(_("Import Number:"), 'Import_Number', '',null, '', true);
ref_cells(_("Supplier Invoice:"), 'Supplier_Invoice', '',null, '', true);
ref_cells(_("Supplier Dispatch VIA:"), 'Supplier_Dispatch_VIA', '',null, '', true);
ref_cells(_("Supplier Dispatch Tracking:"), 'Supplier_Dispatch_Tracking', '',null, '', true);
ref_cells(_("Supplier Repairing GRN:"), 'Supplier_Repairing_GRN', '',null, '', true);
ref_cells(_("Required For:"), 'Required_For', '',null, '', true);
repairing_list_cells("Repairing Status", 'rep_status', null,true);
supplier_list_cells(_("Supplier:"), 'supplier_id', null, false, false, false, true);
material1_list_cells(_("Material Center:"), 'material_center', null, false, false, false, true);
custom_gst_type_list_cells1(_("PO Type"), 'pr_type', null, '', '', false);
delivery_terms_list_cells(_("Delivery Terms:"), 'delivery_terms', null);
shipmentmode_list_cells(_("Shipment Mode:"), 'shipment_mode', null);

end_row();
start_row();
submit_cells('SearchOrders', _("Search"),'',_('Select documents'), 'default');
//locations_list_cells(_("into location:"), 'StockLocation', null, true);
end_row();
end_table();

//start_table(TABLESTYLE_NOBORDER);
//start_row();
//
////stock_items_list_cells(_("for item:"), 'SelectStockFromList', null, true);
//
//
//end_row();
end_table(1);
//---------------------------------------------------------------------------------------------
if (isset($_POST['order_number']))
{
	$order_number = $_POST['order_number'];
}

if (isset($_POST['SelectStockFromList']) &&	($_POST['SelectStockFromList'] != "") &&
	($_POST['SelectStockFromList'] != ALL_TEXT))
{
	$selected_stock_item = $_POST['SelectStockFromList'];
}
else
{
	unset($selected_stock_item);
}

//---------------------------------------------------------------------------------------------
function trans_view($trans)
{
	return get_supplier_trans_view_str(ST_REPAIRINGSUPPLIER, $trans["order_no"]);
}

function edit_link($row)
{
	if (@$_GET['popup'])
		return '';
	return pager_link( _("Edit"),
		"/purchasing/repairing_through_supplier.php?".SID."ModifyOrderNumber=" . $row["order_no"], ICON_EDIT);
}

function prt_link($row)
{
	return print_document_link($row['order_no'], _("Print"), true, 18, ICON_PRINT);
}

function get_dispatched($t_type)
{
    if ($t_type['dispatch_to_supplier'] == 0)
        $name = "Dispatch";
    else
        $name = "Not Dispatch";
    return $name;
}
function get_repairing_status_name_for_dashboard($id)
{
     return get_repairing_status_name($id['rep_status']);
}

function systype_name($dummy, $type)
{
    global $systypes_array;
    return $systypes_array[$type];
}
function get_delivery_terms_name_for_dashboard($id)
{
    $sql = "SELECT terms 
 			FROM ".TB_PREF."delivery_terms 
 			WHERE terms_indicator = ".db_escape($id['delivery_terms']);
    $db = db_query($sql, "Error");
    $ft = db_fetch($db);
    return $ft[0];
}
function get_shipment_mode_name_for_dashboard($id)
{
    $sql = "SELECT name 
 			FROM ".TB_PREF."shipmentmode 
 			WHERE id = ".db_escape($id['shipment_mode']);
    $db = db_query($sql, "Error");
    $ft = db_fetch($db);
    return $ft[0];
}
//---------------------------------------------------------------------------------------------

$sql = get_sql_for_repairing_supplier($_POST['transaction_series'], $_POST['dispatch_to_supplier'],
    $_POST['Supplier_Repairing_Reference'], $_POST['Repairing_Transaction_ID'], $_POST['GRN_Transaction_ID'],
    $_POST['Dispatch_Status'], $_POST['rep_status'], $_POST['Voucher'], $_POST['supplier_id'],
    $_POST['material_center'], $_POST['Inspection_report_DCN'], $_POST['Our_Service_order_to_Supplier'],
    $_POST['GTS_Dispatch_VIA'], $_POST['GTS_Dispatch_Tracking'], $_POST['pr_type'], $_POST['Import_Number'],
    $_POST['Supplier_Invoice'], $_POST['Supplier_Dispatch_VIA'], $_POST['Supplier_Dispatch_Tracking'],
    $_POST['Supplier_Repairing_GRN'], $_POST['delivery_terms'], $_POST['Required_For'], $_POST['shipment_mode']);

$cols = array(
    _("#") => array('fun'=>'trans_view', 'ord'=>''),
    _("Transaction Series") => array('fun'=>'get_transaction_series_name'),
    _("Dispatch to Supplier") => array('fun'=>'get_dispatched'),
    _("Supplier Repairing Reference"),
    _("Repairing Transaction ID"),
    _("GRN Trasaction ID"),
    _("Dispatch Status"),
    _("Repairing Status") => array('fun'=>'get_repairing_status_name_for_dashboard'),
    _("Voucher#"),
    _("Supplier Invoice date") => array('type'=>'date', 'ord'=>'desc'),
	_("Supplier") => array('ord'=>''),
    _("Date") => array('type'=>'date', 'ord'=>'desc'),
	_("Material Centre") => array('fun'=>'get_material_centre_name'),
	_("Inspection report/DCN #"),
	_("Our Service order to Suppplier #"),
	_("GTS Dispatch VIA"),
	_("GTS Dispatch Date") => array('type'=>'date', 'ord'=>'desc'),
	_("Supplier Dispatch Date") => array('type'=>'date', 'ord'=>'desc'),
	_("GTS Dispatch Tracking #"),
	_("PR Type") => array('fun'=>'systype_name'),
	_("Import number"),
	_("Service order Date") => array('type'=>'date', 'ord'=>'desc'),
	_("Supplier Invoice"),
	_("Supplier Dispatch VIA"),
	_("Supplier Dispatch Tracking"),
	_("Supplier Repiaring GRN"),
    _("Delivery Terms") => array('fun'=>'get_delivery_terms_name_for_dashboard'),
    _("Required For"),
    _("Shipment Mode") => array('fun'=>'get_shipment_mode_name_for_dashboard'),
	_("Order Total") => 'amount',
	array('insert'=>true, 'fun'=>'edit_link'),
	array('insert'=>true, 'fun'=>'prt_link'),
);

if (get_post('StockLocation') != $all_items) {
	$cols[_("Location")] = 'skip';
}
//---------------------------------------------------------------------------------------------------

$table =& new_db_pager('orders_tbl', $sql, $cols);

$table->width = "80%";

display_db_pager($table);

if (!@$_GET['popup'])
{
	end_form();
	end_page();
}
?>